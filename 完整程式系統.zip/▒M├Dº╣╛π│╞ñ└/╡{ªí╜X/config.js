import { initializeApp } from '@firebase/app';
import { getAuth } from '@firebase/auth';
import { getFirestore } from '@firebase/firestore';
import { getDatabase } from '@firebase/database';
import { getStorage } from '@firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyAYGpjXR4rueuqpidhDd9qRFVaN1FpL2tU",
  authDomain: "medicine-f678c.firebaseapp.com",
  databaseURL: "https://medicine-f678c-default-rtdb.firebaseio.com",
  projectId: "medicine-f678c",
  storageBucket: "medicine-f678c.appspot.com",
  messagingSenderId: "158120327049",
  appId: "1:158120327049:web:c6e6e000d4c493c3291358",
  measurementId: "G-WNEDM3PEX9"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const firestore = getFirestore(app);
export const database = getDatabase(app);
export const storage = getStorage(app);


