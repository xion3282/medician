import React, { useState, useEffect } from 'react';
import { auth } from './config'; // 替换为您的 firebase 配置文件的路径
import AuthContext from './navigation/AuthContext'; // 替换为您的 AuthContext 文件的路径
import MainContainer from './navigation/MainContainer';
import { LogBox } from 'react-native';
// import { extendDateBy30Days } from "../navigation/dateUtils"; 
LogBox.ignoreAllLogs();

function App() {
  // 在應用程式入口處初始化通知
  
  const [userId, setUserId] = useState(null);

  useEffect(() => {
    const unsubscribe = auth.onAuthStateChanged(user => {
      setUserId(user ? user.uid : null);
    });

    return () => unsubscribe();
  }, []);


  return (
    <AuthContext.Provider value={userId}>
      <MainContainer />
    </AuthContext.Provider>
  );
}

export default App;
