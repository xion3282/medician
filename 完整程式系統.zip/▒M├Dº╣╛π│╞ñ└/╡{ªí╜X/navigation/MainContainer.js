import React, { useState } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { createStackNavigator } from '@react-navigation/stack';
import Ionicons from 'react-native-vector-icons/Ionicons';

// Screens
import HomeScreen from './screens/HomeScreen';
import SettingsScreen from './screens/SettingsScreen';
import MalertScreen from './screens/MalertScreen';
import FnScreen from './screens/FnScreen';
import HdScreen from './screens/HdScreen';
import SrScreen from './screens/SrScreen';
import FamilyEditScreen from './screens/FamilyEditScreen';
import SaveEditScreen from './screens/SaveEditScreen';
import MemberScreen from './screens/MemberScreen';
import DataMemberScreen from './screens/DataMemberScreen';
import HdAddScreen from './screens/HdAddScreen';
import WhScreen from './screens/WhScreen';
import BpScreen from './screens/BpScreen';
import BsScreen from './screens/BsScreen';
import FamilyNicknameScreen from './screens/FamilyNicknameScreen';
import SreScreen from './screens/SreScreen';
import LoginScreen from './screens/LoginScreen';
import SignupScreen from './screens/SignupScreen';
import AddAlert from './screens/AddAlert';
import DetailsScreen from './screens/DetailsScreen';
import EditAlertScreen from './screens/EditAlertScreen';
import useAuth from './hooks/useAuth';
import EditDataMember from './screens/EditDataMemberScreen';
import FamilyMemberDetail from './screens/FamilyMemberDetails';

import DmScreen from './screens/DmScreen';
import RdScreen from'./screens/RdScreen';

// import DrugScreen from './screens/DmScreen';
// import IngredientScreen from './screens/IngredientScreen';
// import ManufacturerScreen from './screens/ManufacturerScreen';
import RefuteScreen from './screens/RefuteScreen';
import MedScreen from './screens/MedScreen';
import SaveScreen from './screens/SaveScreen';

import Whupdata from './screens/Whupdata';
import Bsupdata from './screens/Bsupdata';
import Bpupdata from './screens/Bpupdata';

import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';

const TopTab = createMaterialTopTabNavigator();

function TopTabNavigator() {
  return (
    <TopTab.Navigator>
      <TopTab.Screen name="Med" component={MedScreen} options={{ title: '藥物' }} />
      <TopTab.Screen name="Refute" component={RefuteScreen} options={{ title: '闢謠' }} />
    </TopTab.Navigator>
  );
}

// Screen names
const homeName = "主頁";
const hdName = "健康日誌";
const settingsName = "設定";
const malertName = "服藥提醒";
const fnName = "家屬動態";
const SrName = "藥知道";

const familyEditName = 'FamilyEdit';
const dataMemberName = 'DataMember';

const hdaddName = "新增身體資訊";
const whName = "新增身高體重";
const bpName = "新增血壓";
const bsName = "新增血糖";
const whupdataName = "更新身高體重";
const bsupdataName = "更新血糖";
const bpupdataName = "更新血壓";


const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

function HdStack() {
    return (
        <Stack.Navigator>
            <Stack.Screen name={hdName} component={HdScreen} options={{headerShown:false}}/>
            <Stack.Screen name={hdaddName} component={HdAddScreen} options={{headerShown:false}}/>
            <Stack.Screen name={whName} component={WhScreen} options={{headerShown:false}}/>
            <Stack.Screen name={bpName} component={BpScreen} options={{headerShown:false}}/>
            <Stack.Screen name={bsName} component={BsScreen} options={{headerShown:false}}/>
            <Stack.Screen name={whupdataName} component={Whupdata} options={{headerShown:false}}/>
            <Stack.Screen name={bsupdataName} component={Bsupdata} options={{headerShown:false}}/>
            <Stack.Screen name={bpupdataName} component={Bpupdata} options={{headerShown:false}}/>
        </Stack.Navigator>
    );
}

function SettingsStack() {
    return (
        <Stack.Navigator>
      <Stack.Screen name="Member" component={MemberScreen} options={{headerShown:false}} />
      <Stack.Screen name={settingsName} component={SettingsScreen} options={{headerShown:false}} />
      <Stack.Screen name={familyEditName} component={FamilyEditScreen} options={{headerShown:false}} />
      <Stack.Screen name="SaveEdit" component={SaveEditScreen} options={{headerShown:false}} />
      <Stack.Screen name={dataMemberName} component={DataMemberScreen} options={{headerShown:false}} />
      <Stack.Screen name="FamilyMemberDetail" component={FamilyMemberDetail} options={{headerShown:false}} />
      <Stack.Screen name="EditDataMember" component={EditDataMember} options={{headerShown:false}} />
      <Stack.Screen name="Login" component={LoginScreen} options={{headerShown:false}} />
      <Stack.Screen name="SrScreen" component={SrScreen} options={{headerShown:false}}  />
        </Stack.Navigator>
    );
}

function MalertStack() {
    return (
        <Stack.Navigator>
            <Stack.Screen name="MalertScreen" component={MalertScreen} options={{headerShown:false}} />
            <Stack.Screen name="AddAlert" component={AddAlert} options={{headerShown:false}}/>
            <Stack.Screen name="DetailsScreen" component={DetailsScreen} options={{headerShown:false}}/>
            <Stack.Screen name="EditAlertScreen" component={EditAlertScreen} options={{headerShown:false}}/>
            <Stack.Screen name="SaveScreen" component={SaveScreen} options={{headerShown:false}}/>
            
        </Stack.Navigator>
    );
}

function SrStack() {
    return (
        <Stack.Navigator>
          <Stack.Screen name="TopTabs" component={TopTabNavigator} options={{headerShown:false}}  />
          <Stack.Screen name="DmScreen" component={DmScreen} options={{headerShown:false}}  />
          <Stack.Screen name="RdScreen" component={RdScreen} options={{headerShown:false}}  />
        </Stack.Navigator>

    );
}
// function HomeScreen(){return (
//     <Stack.Navigator>
//         <Stack.Screen name="MalertScreen" component={MalertScreen} options={{headerShown:false}} />
//         <Stack.Screen name="AddAlert" component={AddAlert} options={{headerShown:false}}/>
//         <Stack.Screen name="DetailsScreen" component={DetailsScreen} options={{headerShown:false}}/>
//         <Stack.Screen name="EditAlertScreen" component={EditAlertScreen} options={{headerShown:false}}/>
//         <Stack.Screen name="SaveScreen" component={SaveScreen} options={{headerShown:false}}/>
        
//     </Stack.Navigator>
// );

// }
function FnStack() {
    return (
        <Stack.Navigator initialRouteName="FamilyNickname">
            <Stack.Screen name="FamilyNickname" component={FamilyNicknameScreen} options={{headerShown: false}} />
            <Stack.Screen name="FnScreen" component={FnScreen} options={{headerShown: false}} />
        </Stack.Navigator>
    );
}

export default function MainContainer() {
  const { user } = useAuth();

  if (!user) {
      return (
          <NavigationContainer>
              <Stack.Navigator initialRouteName='Login'>
                  <Stack.Screen name="Login" options={{ headerShown: false }} component={LoginScreen} />
                  <Stack.Screen name="SignUp" options={{ headerShown: false }} component={SignupScreen} />
              </Stack.Navigator>
          </NavigationContainer>
      );
  } else {
      return (
          <NavigationContainer>
             <Tab.Navigator
    screenOptions={({ route }) => ({
        tabBarIcon: ({ focused, color, size }) => {
            let iconName;

            if (route.name === homeName) {
                iconName = focused ? 'home' : 'home-outline';
            } else if (route.name === malertName) {
                iconName = focused ? 'alarm' : 'alarm-outline';
            } else if (route.name === hdName) {
                iconName = focused ? 'document-text' : 'document-text-outline';
            } else if (route.name === fnName) {
                iconName = focused ? 'people' : 'people-outline';
            } else if (route.name === SrName) {
                iconName = focused ? 'search' : 'search-outline';
            } else if (route.name === settingsName) {
                iconName = focused ? 'settings' : 'settings-outline';
            }

            // You can return any component that you like here!
            return <Ionicons name={iconName} size={size} color={color} />;
        },
    })}
    tabBarOptions={{
        activeTintColor: '#000080',
        inactiveTintColor: 'gray',
    }}
>
    <Tab.Screen name={homeName} component={HomeScreen} />
    <Tab.Screen name={malertName} component={MalertStack} />
    <Tab.Screen name={hdName} component={HdStack} />
    <Tab.Screen name={fnName} component={FnStack} />
    <Tab.Screen name={SrName} component={SrStack} />
    <Tab.Screen name={settingsName} component={SettingsStack} />
</Tab.Navigator>
          </NavigationContainer>
      );
  }
}


