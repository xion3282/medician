import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, ScrollView, Switch } from 'react-native';
import { firestore, } from '../../config';
import { doc, updateDoc } from '@firebase/firestore';
import { deleteDoc } from '@firebase/firestore'; // 引入 deleteDoc 函数

export default function SaveEditScreen({ route, navigation }) {
  const { user } = route.params;
  const [nickname, setNickname] = useState(user.nickname);
  const [account, setAccount] = useState(user.account);
  const [authorizationCode, setAuthorizationCode] = useState(user.authorizationCode);
  const [receiveNotification, setReceiveNotification] = useState(user.receiveNotification);

  useEffect(() => {
    // 初始化state变量
    setNickname(user.nickname);
    setAccount(user.account);
    setAuthorizationCode(user.authorizationCode);
    setReceiveNotification(user.receiveNotification);
  }, [user]);

  const handleSave = async () => {
    try {
      console.log("user object: ", user); // 检查user对象
      console.log("user.uid: ", user.uid); // 检查user.uid
      console.log("user.id: ", user.id); // 检查user.id
      // 获取文档引用并更新数据
      const memberDocRef = doc(firestore, 'users', user.uid, 'memberdata', user.id);
      await updateDoc(memberDocRef, {
        nickname,
        account,
        authorizationCode,
        receiveNotification
      });
      
      // 返回到前一个屏幕
      navigation.goBack();

    } catch (error) {
      console.error("Error updating document: ", error);
    }
  };
  const handleDelete = async () => {
    try {
      const memberDocRef = doc(firestore, 'users', user.uid, 'memberdata', user.id);
      await deleteDoc(memberDocRef); // 使用 deleteDoc 函数来删除文档
  
      // 删除完成后导航到 SettingsScreen
      navigation.navigate('設定');
  
    } catch (error) {
      console.error("Error deleting document: ", error);
    }
};


  return (
    <ScrollView>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <View style={styles.container}>
          <Text style={{ fontWeight: 'bold', fontSize: 35, marginBottom: 20, textAlign: 'center' }}>編輯家屬資料</Text>
          <Text style={styles.label}>家屬暱稱</Text>
          <TextInput
            style={styles.input}
            value={nickname}
            onChangeText={setNickname} 
            placeholder="輸入家屬暱稱"
          />
          <Text style={styles.label}>家屬帳號</Text>
          <TextInput
            style={styles.input}
            value={account}
            onChangeText={setAccount} 
            placeholder="輸入家屬帳號"
          />
          <Text style={styles.label}>家屬授權碼</Text>
          <TextInput
            style={styles.input}
            value={authorizationCode}
            onChangeText={setAuthorizationCode} 
            placeholder="輸入家屬授權碼"
          />
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          </View>
          <View style={{ flexDirection: 'row', alignItems: 'center' }}>
            <Switch
              value={receiveNotification}
              onValueChange={setReceiveNotification} 
            />
            <Text style={{ marginLeft: 2, fontSize: 20, marginBottom: 3, fontWeight: 'bold' }}>是否接受家屬服藥通知</Text>
          </View>
          <View style={styles.buttonContainer}>

            <TouchableOpacity onPress={() => navigation.navigate('FamilyEdit')} style={styles.cancelButton}>
              <Text style={styles.buttonText}>取消</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={handleDelete} style={styles.deleteButton}>
      <Text style={styles.buttonText}>刪除</Text>
    </TouchableOpacity>
            <TouchableOpacity onPress={handleSave} style={styles.addButton}>
              <Text style={styles.buttonText}>更新</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 40,
    paddingVertical: 135,
    padding: 10,
    borderWidth: 25,
    borderColor: '#9AA1AB',
    borderRadius: 40,
    backgroundColor: '#F5F7FC',
    paddingTop: 50
  },   
  label: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 15,
  },
  input: {
    height: 55,
    borderColor: 'darkgray',
    borderWidth: 2,
    borderRadius: 10,
    marginBottom: 28,
    paddingHorizontal: 10,
  },
  addButton: {
    backgroundColor: '#203864',
    padding: 10,
    borderRadius: 5,
    margin: 10
  },
  cancelButton: {
    backgroundColor: '#BFBFBF',
    padding: 10,
    borderRadius: 5,
    margin: 10
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 20,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  deleteButton: {
    backgroundColor: '#BFBFBF', 
    padding: 10,
    borderRadius: 5,
    margin: 10
  },
});