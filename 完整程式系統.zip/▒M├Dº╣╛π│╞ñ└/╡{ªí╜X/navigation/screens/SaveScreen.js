import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import React,{useState}from 'react';
import { StyleSheet,Text,View,Button,Image,TextInput, TouchableOpacity } from 'react-native';
import Image1 from '../../assets/09.jpg';
import Image2 from '../../assets/10.jpg';
import Image3 from '../../assets/11.jpg';
import Image4 from '../../assets/12.jpg';


export default function SaveScreen({ navigation }) {

  return (
    <View style={styles.header}>
        <KeyboardAwareScrollView>
          <View>
          <Image source={Image1} style={styles.imageStyle} />
          <Image source={Image2} style={styles.imageStyle} /> 
          <Image source={Image3} style={styles.imageStyle} />
          <Image source={Image4} style={styles.imageStyle} />       
          </View> 
        </KeyboardAwareScrollView>

            </View>    
  );
}

const styles = StyleSheet.create({
  header : {
      flex: 1,
      backgroundColor: "#f5f7fc",
      alignItems:'center',
      justifyContent:'center',
   },
   imageStyle: {
      flex: 1,
      marginTop: 5,
     
      width: 400,  // 這裡的尺寸可以根據你的需求來調整
      height: 600,
      resizeMode: 'contain',  // 這會讓圖片在組件中完整顯示
      marginVertical: 20,   // 上下間距，也可以根據你的需求來調整
      
  },
      
});
