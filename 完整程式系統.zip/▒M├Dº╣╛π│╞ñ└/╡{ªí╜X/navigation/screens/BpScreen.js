import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Dimensions, TextInput, StyleSheet } from 'react-native';
import { auth, firestore } from '../../config';
import { addDoc, collection, doc } from '@firebase/firestore';

const formatDate = (date) => {
  const offset = date.getTimezoneOffset();
  const localDate = new Date(date.getTime() - (offset * 60 * 1000));
  return localDate.toISOString().split('T')[0];
};


export default function BpScreen({ navigation, route }) {
  const { selectedDate } = route.params;
  const [diastolicPressure, setDiastolicPressure] = useState('');
  const [systolicPressure, setSystolicPressure] = useState('');

  const bpauth = async () => {
    try {
      const user = auth.currentUser;
      if (!user) {
        alert('用戶未登錄');
        return;
      }
      const uid = user.uid;
      const userDocRef = doc(firestore, 'users', uid);
      const bpRef = collection(userDocRef, 'BloodPressure');
      const data = {
        diastolicPressure: diastolicPressure,
        systolicPressure: systolicPressure,
        createdBP: formatDate(selectedDate),
      };

      await addDoc(bpRef, data);
      navigation.navigate('健康日誌');
      setDiastolicPressure('');
      setSystolicPressure('');
    } catch (error) {
      console.error("保存數據出錯：", error);
      alert("保存數據出錯");
    }
  }

  return (
    <View style={{ flex: 1 }}>

      <View style={styles.inputContainer}>
        <Text style={styles.bloodPressureText}>血壓</Text>

        <View style={styles.inputRow}>
          <View style={styles.labelContainer}>
            <Text style={styles.labelText}>收縮壓</Text>
          </View>
          <TextInput
            placeholder="輸入收縮壓"
            onChangeText={(diastolicPressure) => setDiastolicPressure(diastolicPressure)}
            value={diastolicPressure}
            style={styles.input}
            keyboardType='numeric'
            maxLength={6}
          />
          <Text style={styles.unitText}>mmHg</Text>
        </View>

        <View style={styles.inputRow}>
          <View style={styles.labelContainer}>
            <Text style={styles.labelText}>舒張壓</Text>
          </View>
          <TextInput
            placeholder="輸入舒張壓"
            style={styles.input}
            onChangeText={(systolicPressure) => setSystolicPressure(systolicPressure)}
            value={systolicPressure}
            keyboardType='numeric'
          />
          <Text style={styles.unitText}>mmHg</Text>
        </View>

        <Text style={styles.reminderText}>(提醒:收縮壓為較大之數值，舒張壓為較小之數值)</Text>

        <View style={styles.buttonContainer}>
          <TouchableOpacity onPress={() => navigation.navigate('健康日誌')} style={styles.cancelButton}>
            <Text style={styles.buttonText}>取消</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={bpauth} style={styles.addButton}>
            <Text style={styles.buttonText}>新增</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  inputContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 10,
    borderWidth: 32,
    borderColor: '#535E6D', // 調整邊框顏色
  },
  bloodPressureText: {
    fontSize: 40,
    fontWeight: 'bold',
    marginBottom: 22,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  labelContainer: {
    backgroundColor: '#2F5597',
    paddingHorizontal: 10,
    paddingVertical: 10,
    borderRadius: 5,
    marginRight: 5,
  },
  labelText: {
    fontSize: 22,
    fontWeight: 'bold',
    color: 'white',
  },
  input: {
    height: 50,
    width: 165,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 10,
    marginBottom: 15,
    paddingHorizontal: 35,
    marginTop: 20,
    textAlign: 'center',
    fontSize: 15,
  },
  unitText: {
    fontSize: 22,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  reminderText: {
    fontSize: 13,
    marginTop: 1,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginTop: 20,
  },
  addButton: {
    backgroundColor: '#203864',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,    
  },
  cancelButton: {
    backgroundColor: '#BFBFBF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginRight: 50,
    marginLeft: 10,
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 20,
  },
});
