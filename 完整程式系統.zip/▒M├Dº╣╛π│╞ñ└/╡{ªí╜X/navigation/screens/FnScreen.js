import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { format } from 'date-fns';
import { auth, firestore } from '../../config';
import { doc, getDoc, collection, getDocs } from '@firebase/firestore';
import Icon from 'react-native-vector-icons/AntDesign'; 
import { ScrollViewComponent } from 'react-native';

export default function FnScreen({ route, navigation }) {
  const familyMemberUid = route.params?.familyMemberUid || '';
  const [familyMemberNickname, setFamilyMemberNickname] = useState(null);
  const [alertsData, setAlertsData] = useState([]);

  useEffect(() => {
    const fetchFamilyData = async () => {
      try {
        const user = auth.currentUser;
        if (!user) {
          console.error("用戶未登錄");
          return;
        }

        console.log("Fetched familyMemberUid from navigation params:", familyMemberUid);

        // 獲取家屬的暱稱
        const userDocRef = doc(firestore, 'users', user.uid);
        const memberDataCollectionRef = collection(userDocRef, 'memberdata');
        const memberDataSnapshot = await getDocs(memberDataCollectionRef);
        const memberDoc = memberDataSnapshot.docs.find(doc => doc.data().familyMemberUid === familyMemberUid);
        if (memberDoc) {
          setFamilyMemberNickname(memberDoc.data().nickname);
        }

        // 獲取家屬的alertData數據
        const familyAlertDataCollectionRef = collection(firestore, 'users', familyMemberUid, 'alertData');
        const familyAlertDataSnapshot = await getDocs(familyAlertDataCollectionRef);
        const alerts = familyAlertDataSnapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data(),
        }));
        setAlertsData(alerts);

      } catch (error) {
        console.error("Error fetching data:", error);
      }
    };
  
    fetchFamilyData();
  }, [familyMemberUid]);

  return (
    <View style={styles.container}>
      <View style={styles.uidContainer}>
        <Icon name="user" size={20} color="#000" />
        <View style={styles.textContainer}>
          <Text style={styles.nicknameText}>家屬暱稱: {familyMemberNickname}</Text>
          <Text style={styles.uidText}>家屬授權碼: {familyMemberUid}</Text>
        </View>
      </View>
      
      {alertsData.map(alert => (
  <View key={alert.id} style={styles.card}>
    <Text style={styles.medicineName}>藥物名稱: {alert.Mname}</Text>
    {alert.selectedTimes?.map((time, index) => (
      <View key={index}>
        <Text style={styles.timeText}>提醒時間: {time?.toDate ? format(time.toDate(), "hh:mm a") : ""}</Text>
        
        <Text style={[
  styles.selectionText,
  !(alert.selectedCircles?.[`${alert.id}_${index}`]?.isSelected) && styles.selectionTextNegative
]}>
  是否已服藥: 
  {alert.selectedCircles?.[`${alert.id}_${index}`]?.isSelected ? '是' : '否'}
</Text>

        {alert.selectedCircles?.[`${alert.id}_${index}`]?.isSelected && (
          <Text style={styles.medicationTime}>
            服藥時間: {format(alert.selectedCircles[`${alert.id}_${index}`].timestamp.toDate(), "hh:mm a")}
          </Text>
        )}
      </View>
    ))}
  </View>
))}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#F5F7FC',
  },
  selectionTextNegative: {
    fontSize: 18,
    color: 'red',
    marginBottom: 5,
  },
  
  uidContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
  },
  textContainer: {
    marginLeft: 8,
  },
  nicknameText: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  uidText: {
    fontSize: 13,
    marginTop: 5,
  },
  card: {
    backgroundColor: '#fff',
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.3,
    shadowRadius: 2,
  },
  medicineName: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  timeText: {
    fontSize: 18,
    color: '#555',
    marginBottom: 5,
  },
  selectionText: {
    fontSize: 18,
    color: '#333',
    marginBottom: 5,
  },
  medicationTime: {
    fontSize: 18,
    color: '#555',
    marginBottom: 10,
  }
});

