import React, { useEffect, useState } from 'react';
import { Text, TouchableOpacity, StyleSheet, ScrollView } from 'react-native';
import { auth, firestore } from '../../config';
import { collection, onSnapshot, doc } from '@firebase/firestore';
import { AntDesign } from '@expo/vector-icons'; // 如果你是用expo安装的AntDesign

export default function SettingsScreen({ navigation }) {
  const [members, setMembers] = useState([]);
  
  useEffect(() => {
    const user = auth.currentUser;
    if(!user) return;

    const uid = user.uid;
    const userDocRef = doc(firestore, 'users', uid);
    const memberDataCollectionRef = collection(userDocRef, 'memberdata');

    // 设置监听器，以便在memberdata发生更改时更新状态
    const unsubscribe = onSnapshot(memberDataCollectionRef, (snapshot) => {
      const memberData = snapshot.docs.map(doc => ({
        id: doc.id, 
        ...doc.data()
      }));
      setMembers(memberData);
    });

    // 清除订阅
    return () => unsubscribe();
  }, []);

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <TouchableOpacity
        style={styles.pluscircleoIcon}
        onPress={() => navigation.navigate('FamilyEdit')}>
        <AntDesign name="pluscircleo" size={35} color="#002080" />
      </TouchableOpacity>
      <Text style={{ fontWeight: 'bold', fontSize: 30, marginBottom: 40, textAlign: 'center' }}>
        家屬資料
      </Text>
      {members.map(member => (
    <TouchableOpacity 
        key={member.id} 
        style={styles.memberButton} 
        onPress={() => navigation.navigate('FamilyMemberDetail', { member })}
    >
        <Text style={styles.memberName}>{member.nickname}</Text>
    </TouchableOpacity>
))}

    </ScrollView>
);
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 40,
    paddingVertical: 175,
    borderRadius: 40,
    backgroundColor: '#F5F7FC',
    paddingTop: 30,
  },
  pluscircleoIcon: {
    position: 'absolute',
    top: 75,
    right: 20,
  },
  memberButton: {
    width: '100%',
    height: 130,
    backgroundColor: '#ccd9ff',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 30,
    borderRadius: 30,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5, // for Android
  },
  
memberName: {
    fontSize: 30, // 字体大小
    color: 'black', // 字体颜色
    fontWeight: 'bold',
}
});
