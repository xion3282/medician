import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet ,TouchableOpacity} from 'react-native';
import { firestore, auth } from '../../config'; // 加入auth
import { doc, getDoc } from '@firebase/firestore';
import { AntDesign } from '@expo/vector-icons';

export default function FamilyMemberDetail({ route, navigation }) { // 在这里添加navigation
  const { member } = route.params; // 接收从 SettingsScreen 传递过来的 member 对象
  const [memberDetails, setMemberDetails] = useState({});
  
  const fetchData = async () => { // 定义fetchData函数
    try {
      const user = auth.currentUser;
      if(!user) return;
  
      const uid = user.uid;
      const memberDocRef = doc(firestore, 'users', uid, 'memberdata', member.id);
      const memberDoc = await getDoc(memberDocRef);
      
      if(memberDoc.exists()) {
        setMemberDetails(memberDoc.data());
      }
    } catch (error) {
      console.error("Error fetching member details: ", error);
    }
  };
  
  useEffect(() => {
    if(!member.id) return;
    
    fetchData(); // 调用fetchData函数
    
    const unsubscribe = navigation.addListener('focus', () => { // 添加navigation事件监听器
      fetchData(); // 每次屏幕获得焦点时，都会调用fetchData函数
    });
    
    return unsubscribe; // 清除订阅
  }, [navigation, member.id]);

  const handleEditPress = () => {
    const user = auth.currentUser;
    if(user) {
      navigation.navigate('SaveEdit', { user: { ...memberDetails, uid: user.uid, id: member.id } });
    }
  };

  return (
    <View style={styles.container}>
      <TouchableOpacity style={styles.editButton} onPress={handleEditPress}>
        <AntDesign name="edit" size={30} color="black" />
      </TouchableOpacity>
      <Text style={styles.headerText}>家屬設定詳細資訊 :</Text>
      <View style={styles.centeredView}>
        <Text style={styles.label}>家屬暱稱:</Text>
        <Text style={styles.detail}>{memberDetails.nickname}</Text>
      </View>
      <View style={styles.centeredView}>
        <Text style={styles.label}>家屬帳號:</Text>
        <Text style={styles.detail}>{memberDetails.account}</Text>
      </View>
      <View style={styles.centeredView}>
        <Text style={styles.label}>家屬授權碼:</Text>
        <Text style={styles.detail}>{memberDetails.authorizationCode}</Text>
      </View>
      <View style={styles.centeredView}>
        <Text style={styles.label}>是否接收通知:</Text>
        <Text style={styles.detail}>
          {memberDetails.receiveNotification ? '是' : '否'}
        </Text>
      </View>
    </View>
  );
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center', // 垂直居中
    paddingHorizontal: 15,
    padding: 10,
    paddingTop: 5,       // 减少顶部的padding
    paddingBottom: 50,  // 增加底部的padding，这样内容会上移
    borderWidth: 25,
    borderColor: '#9AA1AB',
    borderRadius: 40,
    backgroundColor: '#F5F7FC',
  },
  centeredView: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    alignItems: 'center',
    marginBottom: 15,
    paddingHorizontal: 0,
    width: '95%',
    flexWrap: 'wrap', // 添加此属性以允许内容换行
  },
  label: {
    fontSize: 20,  // 减小字体大小
    fontWeight: 'bold',
    marginBottom: 15,
    marginRight: 5,
    textAlign: 'left',
  },
  detail: {
    fontSize: 20,  // 减小字体大小
    marginBottom: 10,
    marginLeft: 10,
    textAlign: 'left',
    maxWidth: '55%',  // 限制最大宽度，可以根据需要进行调整
  },
  editButton: {
    position: 'absolute',
    top: 15,
    right: 15,
  },
  headerText: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 30,
    textAlign: 'center', // 这样标题仍然会居中
  },
});
