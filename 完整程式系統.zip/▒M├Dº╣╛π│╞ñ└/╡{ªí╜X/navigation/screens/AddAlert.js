import React, { useState, useEffect, useRef,useContext } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Image, TextInput,ScrollView,Keyboard} from 'react-native';
import { Camera } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import ModalDropdown from 'react-native-modal-dropdown';
import DateTimePicker from '@react-native-community/datetimepicker';
import { firebaseApp,storage} from '../../config';
import AuthContext from '../AuthContext'; 
import { getFirestore, collection, addDoc, serverTimestamp, doc } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import * as Notifications from "expo-notifications";
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';

export default function AddAlert({ navigation }) { 
  
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: false,
    shouldSetBadge: false,
  }),
});
const syncUnits = (selectedUnit) => {
  setUnitTotal(selectedUnit);
  setUnitPerDose(selectedUnit);
};
  const userId = useContext(AuthContext);
const db = getFirestore(firebaseApp);
  const userDocRef = doc(db, 'users', userId);
  const alertDataCollectionRef = collection(userDocRef, 'alertData');
  
  const [addMname, setMname] = useState('');
  const [addMsum, setMsum] = useState('');
  const [addMevery, setMevery] = useState('');
  const [unitTotal, setUnitTotal] = useState("包");
const [unitPerDose, setUnitPerDose] = useState("包");

  // const [unit, setUnit] = useState("包");
  // const [selectedFrequency, setSelectedFrequency] = useState('1');

  const uploadImage = async (imageUri) => {
    // 創建一個對Storage的參照路徑，這裡我隨機產生一個文件名稱，您也可以按照自己的方式進行命名
    const fileName = new Date().getTime() + '.jpg';
    const storageRef = ref(storage, 'images/' + fileName);
  
    // 轉換圖片uri為blob，這是上傳到Firebase Storage所需的格式
    const response = await fetch(imageUri);
    const blob = await response.blob();
  
    // 上傳blob到Firebase Storage
    await uploadBytes(storageRef, blob);
  
    // 如果需要，獲取圖片的URL
    const imageUrl = await getDownloadURL(storageRef);
    
    return imageUrl; // 這是存儲在Firebase Storage的圖片URL，您可以存儲到Firestore或其他地方
  }
  
 
 const DeletAdd = () => {
  // 執行刪除操作的邏輯
  console.log('刪除');
  // 清空輸入框的數值
  setMname('');
  setMsum('');
  setMevery('');
  setSelectedFrequency('1');
  setSelectedTime(new Date());
  setSelectedTime1(new Date());
  setSelectedTime2(new Date());
  setStartDate(new Date());          
  setEndDate(new Date());         
       Keyboard.dismiss();                             
};

const scheduleNotification = async (Mevery,Munit,Mname,time, frequency, startDate, endDate) => {
  // Request permissions
  const { status } = await Notifications.requestPermissionsAsync();
  if (status !== 'granted') {
    alert('通知權限被拒绝！');
    return;
  }

  const secondsInADay = 24 * 60 * 60; // 一天的秒数

  let currentDate = new Date(startDate); // 从开始日期开始
  endDate = new Date(endDate);
  while (currentDate <= endDate) {
    const notificationTime = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth(),
      currentDate.getDate(),
      time.getHours(),
      time.getMinutes(),
      time.getSeconds()
    );
  const titleSuffix = Mname.includes('藥') ? '' : '藥';
  const notificationTitle = `${Mevery}${Munit}${Mname}${titleSuffix}`;

    if (notificationTime > new Date()) {
      const notificationId =// 只安排未来的通知
      await Notifications.scheduleNotificationAsync({
        content: {
          title: notificationTitle,
          body: '服藥時間到了!!'
        },
        trigger: notificationTime,
      });
    }

    currentDate.setDate(currentDate.getDate() + parseInt(frequency)); // 移到下一天
  }
};

const addField = async () => {


  if (addMname && addMsum && addMevery && addMname.length > 0) {
    try {
      let imageUrl = null;
      if (image) {
        imageUrl = await uploadImage(image);
      }
      
      // Create an array to hold the selected times
      const selectedTimes = timePickers
        .slice(0, parseInt(selectedFrequency))
        .map((picker, index) => picker.value);
      
      const docData = {
        createdAt: serverTimestamp(),
        Mname: addMname,
        Msum: addMsum,
        Munit: unitTotal,
        Mevery: addMevery,
        frequency: selectedFrequency,
        startD: startDate,
        endD: endDate,
        imageUrl: imageUrl,
        selectedTimes: selectedTimes, // Use an array to store selected times
      };

      // Adding the docData to Firestore
      await addDoc(alertDataCollectionRef, docData);

      console.log('新增成功');
      setMname('');
      setMsum('');
      setMevery('');
      setUnitTotal('包');
      setSelectedFrequency('1');
      setStartDate(new Date());
      setEndDate(new Date());
      setSelectedTime(new Date());
      Keyboard.dismiss();

      // // 调度通知
      // scheduleNotification(selectedTime, selectedFrequency, startDate, endDate);

      // 对于每个选定的时间，调度通知
      selectedTimes.forEach(async (time) => {
        await scheduleNotification(addMevery,unitTotal,addMname, time, selectedFrequency, startDate, endDate);
      });

      // 导航到 MalertScreen
      navigation.navigate('MalertScreen');
    } catch (error) {
      console.error('新增数据时出错：', error);
      alert('新增数据时出错');
    }
  }
};


 const [selectedFrequency, setSelectedFrequency] = useState('1');

  const [hasPermission, setHasPermission] = useState(null);
  const [image, setImage] = useState(null);
  const [useCamera, setUseCamera] = useState(false);
  const cameraRef = useRef(null);
  const [type, setType] = useState(Camera.Constants.Type.back);

  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEndDatePicker, setShowEndDatePicker] = useState(false);

 
  const handleStartDateChange = (event, selectedDate) => {
    const currentDate = selectedDate || startDate;
    setShowStartDatePicker(false);
    setStartDate(currentDate);
  };

  const handleEndDateChange = (event, selectedDate) => {
    const currentDate = selectedDate || endDate;
    setShowEndDatePicker(false);
    setEndDate(currentDate);
  };

  const showStartDatePickers = () => {
    setShowStartDatePicker(true);
  };

  const showEndDatePickers = () => {
    setShowEndDatePicker(true);
  };

  const [selectedTime, setSelectedTime] = useState(new Date());
  const [selectedTime1, setSelectedTime1] = useState(new Date());
  const [selectedTime2, setSelectedTime2] = useState(new Date());
  const [selectedTime3, setSelectedTime3] = useState(new Date());
  // const [showTimePicker, setShowTimepicker] = useState(false);
  // const [showTimePicker1, setShowTimepicker1] = useState(false);
  // const [showTimePicker2, setShowTimepicker2] = useState(false);

  const handleTimeChange = (index, selected) => {
    setTimePickers(timePickers => timePickers.map((picker, i) => 
      i === index ? { ...picker, value: selected || picker.value, show: false } : picker
    ));
  };

  const [timePickers, setTimePickers] = useState([
    { value: new Date(), show: false },
    { value: new Date(), show: false },
    { value: new Date(), show: false },
    { value: new Date(), show: false },

  ]);
  

  useEffect(() => {
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: false,
        shouldSetBadge: false,
      }),
    });

    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === 'granted');

      
       })();
    }, []);

  if (hasPermission === null) {
    return <View />;
  }
  if (hasPermission === false) {
    return <Text>No access to camera</Text>;
  }

  const takePicture = async () => {
    if (cameraRef) {
      console.log('in take picture');
      try {
        let photo = await cameraRef.current.takePictureAsync({
          allowsEditing: true,
          aspect: [4, 3],
          quality: 1,
        });
        return photo;
      } catch (e) {
        console.log(e);
      }
    }
  };

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.cancelled) {
      return result;
    }
  };

  return (
    <KeyboardAwareScrollView style={{backgroundColor:'#f5f7fc'}}>
    <View style={styles.container}>
      <View style={{ flex: 1, marginTop: 5, backgroundColor: '#f5f7fc', alignItems: 'center', borderTopLeftRadius: 40, borderTopRightRadius: 40, borderBottomLeftRadius: 40, borderBottomRightRadius: 40, overflow: 'hidden' }}>
        <View style={{ height: 600, width: 600,alignItems: 'center',marginTop:5 }}>
          <Text style={{ fontSize: 20, color: 'black' }}>名稱</Text>
          <TextInput
            style={styles.TextInput3}
            backgroundColor='white'
            placeholder="請輸入名稱"
            maxLength={10}
            onChangeText={(Mname) => setMname(Mname)}
            value={addMname}
          />

<Text style={{ fontSize: 20, color: 'black', marginTop: 5 }}>總劑量</Text>
    <View style={styles.buttonRow1}>
    <TextInput
            style={styles.TextInput}
            backgroundColor='white'
            placeholder="請輸入數量"
            keyboardType='numeric'
            maxLength={3}
            onChangeText={(Msum) => setMsum(Msum)}
            value={addMsum}
          />
        
        <ModalDropdown 
    options={['包', '顆']} 
    dropdownTextStyle={{ fontSize: 20 }} 
    defaultValue="包" 
    renderButtonText={(rowData) => {
        syncUnits(rowData);
        return <Text style={{ fontSize: 20 }}>{rowData}</Text>;
    }}
    selectedValue={unitTotal}
/>
</View>
           
          <Text style={{ fontSize: 20, color: 'black',marginTop:5}}>每次服用量</Text>
          <View style={styles.buttonRow1}>
          <TextInput
            style={styles.TextInput}
            backgroundColor='white'
            placeholder="請輸入數量"
            keyboardType='numeric'
            maxLength={2}
            onChangeText={(Mevery) => setMevery(Mevery)}
            value={addMevery}
          />
        <Text style={{ fontSize: 20, color: 'black' }}>{unitTotal}</Text>
</View>
          <Text style={{ fontSize: 20, color: 'black',marginTop:5}}>每天服藥次數</Text>
          <ModalDropdown
          options={['1', '2', '3', '4']}
         dropdownTextStyle={{ fontSize: 20 }}
          defaultValue={selectedFrequency}
          renderButtonText={(rowData) => <Text style={{ fontSize: 20 }}>{rowData}</Text>}
          onSelect={(index, value) => setSelectedFrequency(value)}
          />

{timePickers.slice(0, parseInt(selectedFrequency)).map((picker, index) => (
  <View key={index} style={styles.buttonRow2}>
    <TouchableOpacity onPress={() => setTimePickers(timePickers => timePickers.map((p, i) => 
      i === index ? { ...p, show: true } : p
    ))}>
      <Text style={styles.TextInput2}>
        {picker.value.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
      </Text>
    </TouchableOpacity>
    {picker.show && (
      <DateTimePicker
        value={picker.value}
        mode="time"
        display="default"
        onChange={(event, selected) => handleTimeChange(index, selected)}
      />
    )}
  </View>
))}

          <Text style={{ fontSize: 20, color: 'black',marginTop:10 }}>開始日期</Text>
          <TouchableOpacity onPress={showStartDatePickers}>
            <Text  style={styles.TextInput1}>{startDate.toLocaleDateString()}</Text>
          </TouchableOpacity>
          {showStartDatePicker && (
            <DateTimePicker
              value={startDate}
              mode="date"
              display="default"
              onChange={handleStartDateChange}
            />
          )}
          <Text style={{ fontSize: 20, color: 'black',marginTop:10 }}>結束日期</Text>
          <TouchableOpacity onPress={showEndDatePickers}>
            <Text style={styles.TextInput1}>{endDate.toLocaleDateString()}</Text>
          </TouchableOpacity>
          {showEndDatePicker && (
            <DateTimePicker
              value={endDate}
              mode="date"
              display="default"
              onChange={handleEndDateChange}
            />
          )}

        </View>
        <View
          style={{
            flex: 2,
            alignItems: 'flex-end',
            justifyContent: 'center',
          }}>
          {useCamera ? (
            <View style={{ alignItems: 'center', justifyContent: 'center' }}>
            <Camera style={styles.camera} type={type} ref={cameraRef}>
                <View style={styles.buttonContainer}>
                  <TouchableOpacity
                    style={styles.button}
                    onPress={() => {
                      setUseCamera(false);
                    }}>
                    <Text style={styles.text}>取消</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.button}
                    onPress={() => {
                      setType(
                        type === Camera.Constants.Type.back
                          ? Camera.Constants.Type.front
                          : Camera.Constants.Type.back
                      );
                    }}>
                    <Text style={styles.text}>翻轉</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.button]}
                    onPress={async () => {
                      console.log('in take pic');
                      const r = await takePicture();
                      setUseCamera(false);
                      if (!r.cancelled) {
                        setImage(r.uri);
                      }
                      console.log('response', JSON.stringify(r));
                    }}>
                    <Text style={styles.text}>拍照</Text>
                  </TouchableOpacity>
                </View>
              </Camera>
            </View>
          ) : (
              <View style={{ width: '100%', marginTop: '-20%' }}>
                <View
                  style={{
                    flexDirection: 'row',
                  }}>
                  <TouchableOpacity
                    style={[styles.button]}
                    onPress={async () => {
                      console.log('in pick photo');
                      const r = await pickImage();
                      if (!r.cancelled) {
                        setImage(r.uri);
                      }
                      console.log('response', JSON.stringify(r));
                    }}>
                  <Text style={styles.text}>圖庫</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.button]}
                    onPress={async () => {
                      console.log('in pick camera');
                      setUseCamera(true);
                    }}>
                    <Text style={styles.text}>拍照</Text>
                  </TouchableOpacity>
                </View>

                <View style={{ width: '100%', alignItems: 'center' }}>
                  {true && (
                    <Image
                      source={{ uri: image }}
                      style={{ width: 200, height: 200, backgroundColor: '#ccd9ff' }}
                    />
                  )}
                </View>
              </View>
            )}
        </View>
        <View style={styles.buttonRow}>
        <TouchableOpacity
            style={styles.button1}
            onPress={() => {
              setUseCamera(false);
              navigation.navigate('MalertScreen'); 
            }}>
            <Text style={styles.text}>取消</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.button1]} onPress={DeletAdd}>
            <Text style={styles.text}>清空</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.button]} onPress={addField}>
            <Text style={styles.text}>新增</Text>
            </TouchableOpacity>
            </View>
      </View>
    </View>
    </KeyboardAwareScrollView>
);
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
    backgroundColor: '#535E6D',
    padding: 10,
    // margin: 1,
  },
  camera: {
    width: 300,
    height: 300,
  },
  buttonContainer: {
    flexDirection: 'row',
    minWidth: '50%',
    flex: 1
  },
  button: {
    flex: 0.5,
    alignItems: 'center',
    justifyContent: 'center',
    width: 100,
    height: 40,
    margin: 10,
    backgroundColor: '#203864',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20
  },
  button1: {
    flex: 0.5,
    alignItems: 'center',
    justifyContent: 'center',
    width: 100,
    height: 40,
    margin: 10,
    backgroundColor: '#BFBFBF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20
  },
  text: {
    fontSize: 18,
    color: 'white',
    fontWeight: 'bold', 
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 20,
  },
  buttonRow2: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 5,
    marginRight:10,
    marginLeft:10,
  },
  buttonRow1: {
    flexDirection: 'row',
    // justifyContent: 'space-between',
    // marginVertical: 10,
    alignItems: 'center',
  },
  TextInput:{
    height: 40,
     borderRadius: 10, 
     fontSize: 20,
     width:200,
  },
  TextInput1:{
    marginVertical: 5,
    height: 30,
     borderRadius: 10, 
     fontSize: 20,
     width:200,
     alignItems:'center',
     backgroundColor:'white',
     borderTopLeftRadius: 20,
     borderTopRightRadius: 20,
     borderBottomLeftRadius: 20,
     borderBottomRightRadius: 20,
      overflow: 'hidden'
  },
  TextInput2:{
    // marginVertical: 5,
    height: 30,
     borderRadius: 10, 
     fontSize: 20,
     width:90,
     alignItems:'center',
     backgroundColor:'white',
     borderTopLeftRadius: 20,
     borderTopRightRadius: 20,
     borderBottomLeftRadius: 20,
     borderBottomRightRadius: 20,
    overflow: 'hidden'
  },
  TextInput3:{
    height: 40,
     borderRadius: 10, 
     fontSize: 20,
     width:200,
     marginTop:5
  },
});    
