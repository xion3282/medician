import { StyleSheet } from 'react-native';

export const inputStyles = StyleSheet.create({
  inputContainer: {
    width: '80%',
    flexDirection: 'column',
    alignItems: 'flex-start',
    marginBottom: 'auto',
  },
  inputTitle: {
    fontSize: 28,
    textAlign: 'left',
    marginBottom: 'auto',
    fontWeight: 'bold',
  },
  input: {
    width: '100%',
    height: 50,
    borderWidth: 1,
    borderColor: '#D9D9D9',
    borderRadius: 5,
    padding: 10,
    fontSize: 20,
    marginTop: 20,
    marginBottom: 'auto'
  },
});
