import React, { useContext } from 'react';
import {Text, View, ScrollView, StyleSheet} from 'react-native';

export default function SrScreen({ navigation }) {

  // const userId = useContext(AuthContext);

  return (
    <ScrollView style={styles.container}>
      <View style={styles.content}>
        <View style={styles.section}>
            <Text style={styles.title}>全部藥品許可證資料集</Text>
            <Text style={styles.link}>https://data.gov.tw/dataset/9122</Text>
        </View>

        <View style={styles.section}>
            <Text style={styles.title}>藥品仿單或外盒資料集</Text>
            <Text style={styles.link}>https://data.gov.tw/dataset/9117</Text>
        </View>

        <View style={styles.section}>
            <Text style={styles.title}>藥品外觀資料集</Text>
            <Text style={styles.link}>https://data.gov.tw/dataset/9120</Text>
        </View>

        <View style={styles.section}>
            <Text style={styles.title}>食藥闢謠專區資料集</Text>
            <Text style={styles.link}>https://data.gov.tw/dataset/17148</Text>
        </View>

        <View style={styles.section}>
            <Text style={styles.title}>保健闢謠</Text>
            <Text style={styles.link}>https://data.gov.tw/dataset/43338</Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#F5F7FC',
  },
  content: {
    padding: 20,
    alignItems: 'center',
    marginTop:25,
  },
  // Uncomment if you need to display userId
  // userId: {
  //   fontSize: 20,
  //   color: 'gray',
  //   marginBottom: 30,
  // },
  section: {
    backgroundColor: '#FFF',
    borderRadius: 10,
    padding: 20,
    marginBottom: 20,
    width: '100%',
    shadowColor: "#000",
    shadowOffset: {
        width: 0,
        height: 2,
    },
    shadowOpacity: 0.2,
    shadowRadius: 3,
    elevation: 2,
  },
  title: {
    fontSize: 25,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#333',
  },
  link: {
    fontSize: 18,
    color: '#3498db',
    textDecorationLine: 'underline',
  }
});
