import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  StyleSheet,
  ScrollView
} from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import { FontAwesome5 } from '@expo/vector-icons';
import { auth, firestore } from '../../config';
import { getFirestore, collection, onSnapshot, doc } from 'firebase/firestore';

export default function MalertScreen({ navigation }) {
  const [alerts, setAlerts] = useState([]);
  const [uid, setUid] = useState(null);

  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    setUid(user.uid); // 將 uid 儲存到 state 中
    const userDocRef = doc(firestore, 'users', user.uid);
    const alertDataCollectionRef = collection(userDocRef, 'alertData');

    // 設置監聽器，以便在 memberdata 發生更改時更新狀態
    const unsubscribe = onSnapshot(alertDataCollectionRef, (snapshot) => {
      const newAlerts = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setAlerts(newAlerts);
    });
    
    return () => unsubscribe();
  }, [auth.currentUser]);

  return (
    <View style={{ flex: 1,backgroundColor: "#f5f7fc"}}>
      <TouchableOpacity
        onPress={() => navigation.navigate('AddAlert')}
        style={{ position: 'absolute', top: 10, right: 10 }}
      >
        <AntDesign name="pluscircleo" size={30} color="#002080" />
      </TouchableOpacity>
      <TouchableOpacity
        onPress={() => navigation.navigate('SaveScreen')}
        style={{ position: 'absolute', top: 10, left: 10 }}
      >
       <FontAwesome5 name="book-medical" size={30} color="#002080" />
      </TouchableOpacity>
      <View style={{ flex: 1, marginTop: 50 }}>
      <FlatList
  style={{ flex: 1 }}
  data={alerts}
  keyExtractor={(item) => item.id}
  numColumns={1}
  renderItem={({ item }) => {
    // Calculate trueCount and remainingDose based on each alert's data
    const trueCount = item.selectedCircles
      ? Object.values(item.selectedCircles).filter(subItem => subItem.isSelected).length
      : 0;
    const dosetaken=item.Mevery * trueCount;
    const remainingDose = item.Msum - dosetaken;

    return (
      <ScrollView style={{backgroundColor: '#f5f7fc'}}>
      <TouchableOpacity
        style={styles.container}
        onPress={() => {
          navigation.navigate('DetailsScreen', {
            itemId: item.id,
            itemName: item.Mname,
            itemSD: item.startD,
            itemED: item.endD,
            uid: uid,
          });
          console.log(item.id, item.Mname, item.startD, item.endD, uid, 'pressed');
        }}
      >
        <View style={styles.innerContainer}>
          <Text style={styles.itemHeading}>{item.Mname}</Text>
          {/* <Text style={styles.itemText}>{item.Msum}{item.Munit}</Text> */}
          {/* <Text style={styles.itemText}>已服用: {dosetaken}{item.Munit}</Text> */}
          <Text style={styles.itemText}>剩餘劑量: {remainingDose}{item.Munit}</Text>
        </View>
      </TouchableOpacity></ScrollView>
    );
  }}
/>

      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    backgroundColor: '#ccd9ff',
    padding: 15,
    borderRadius: 15,
    margin: 5,
    marginHorizontal: 10,
  },
  innerContainer: {
    alignContent: 'center',
    flexDirection: 'column',
  },
  itemHeading: {
    fontWeight: 'bold',
    color: '#002080',
    fontSize: 25,
    marginBottom: 5,
  },
  itemText: {
    fontWeight: '500',
    color: '#00134d',
    fontSize: 20,
  },
});
