import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { firestore, auth } from '../../config';
import { doc, updateDoc } from '@firebase/firestore';

const formatDate = (date) => {
    const offset = date.getTimezoneOffset();
    const localDate = new Date(date.getTime() - (offset * 60 * 1000));
    return localDate.toISOString().split('T')[0];
};

export default function Whupdata({ route, navigation }) {
    const { data, selectedDate } = route.params;
    const [height, setHeight] = useState(data.height);
    const [weight, setWeight] = useState(data.weight);

    const handleUpdate = async () => {
        try {
            const user = auth.currentUser;
            if (!user) return;

            const uid = user.uid;
            const userDocRef = doc(firestore, 'users', uid);
            const whDocRef = doc(userDocRef, 'HeightWeight', data.id);

            await updateDoc(whDocRef, {
                height: height,
                weight: weight,
                createdWH: formatDate(selectedDate),
            });

            Alert.alert("更新成功");
            navigation.goBack(); // 返回到 HdScreen 畫面
        } catch (error) {
            console.error("更新錯誤: ", error);
            Alert.alert("更新錯誤", "請稍後再試");
        }
    };

    return (
        <View style={{ flex: 1 }}>
            <View style={styles.inputContainer}>
                <View style={styles.inputRow}></View>
                <View style={styles.container}>
                    <Text style={styles.label}>身高</Text>
                    <TextInput
                        value={height.toString()}
                        onChangeText={setHeight}
                        style={styles.input}
                        keyboardType="numeric"
                        placeholder="輸入身高"
                    />
                    <Text style={styles.label}>體重</Text>
                    <TextInput
                        value={weight.toString()}
                        onChangeText={setWeight}
                        style={styles.input}
                        keyboardType="numeric"
                        placeholder="輸入體重"
                    />
                </View>
                <View style={styles.buttonContainer}>
                    <TouchableOpacity onPress={() => navigation.navigate('健康日誌')} style={styles.cancelButton}>
                        <Text style={styles.buttonText}>取消</Text>
                    </TouchableOpacity>

                    <TouchableOpacity onPress={handleUpdate} style={styles.addButton}>
                        <Text style={styles.buttonText}>更新</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    inputContainer: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      backgroundColor: 'white',
      padding: 10,
      borderWidth: 40,
      borderColor: '#535E6D',
    },
    inputRow: {
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 10,
      justifyContent: 'center',
    },
    label: {
      fontSize: 30,
      fontWeight: 'bold',
      marginRight: 15, // 調整文字與框框之間的距離
    },
    input: {
      height: 50,
      width: 165,
      borderColor: 'gray',
      borderWidth: 1,
      borderRadius: 10,
      marginBottom: 25,
      paddingHorizontal: 50,
      textAlign: 'center',
      fontSize:25,
    },
    buttonContainer: {
      flexDirection: 'row',
      justifyContent: 'flex-start',
      marginTop: 20,
    },
    addButton: {
      backgroundColor: '#203864',
      paddingHorizontal: 20,
      paddingVertical: 10,
      borderRadius: 5,
      
    },
    cancelButton: {
      backgroundColor: '#BFBFBF',
      paddingHorizontal: 20,
      paddingVertical: 10,
      borderRadius: 5,
      marginRight: 50,
      marginLeft: 10,
    },
    buttonText: {
      color: '#FFFFFF',
      fontWeight: 'bold',
      textAlign: 'center',
      fontSize: 20,
    },
  });
