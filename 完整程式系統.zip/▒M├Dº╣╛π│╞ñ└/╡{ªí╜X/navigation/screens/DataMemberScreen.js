import React, { useState, useCallback } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Alert } from 'react-native';
import { getFirestore, doc, getDoc } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useNavigation, useFocusEffect } from '@react-navigation/native';
import * as Clipboard from 'expo-clipboard'; // 使用expo-clipboard代替

export default function DataMemberScreen() {
  const navigation = useNavigation();
  const [userData, setUserData] = useState(null);

  const fetchData = useCallback(async () => {
    const db = getFirestore();
    const auth = getAuth();
    const user = auth.currentUser;

    if (user) {
      const userDocRef = doc(db, 'users', user.uid);
      const userDoc = await getDoc(userDocRef);
      if (userDoc.exists()) {
        setUserData({
          ...userDoc.data(),
          uid: user.uid
        });
      } else {
        console.log('No such document!');
      }
    } else {
      console.log('No user is signed in.');
    }
  }, []);
  
  useFocusEffect(
    useCallback(() => {
      fetchData();
      return () => {}; 
    }, [fetchData])
  );

  const copyToClipboard = () => {
    if (userData && userData.uid) {
      Clipboard.setString(userData.uid);
      Alert.alert("提示", "家屬授權碼已複製");
    }
  };

  return (
    <KeyboardAwareScrollView style={styles.scrollView}>
      <View style={styles.container}>
        <View style={styles.titleContainer}>
          <Text style={styles.title}>會員資料</Text>
          <TouchableOpacity onPress={() => navigation.navigate('EditDataMember')} style={styles.editButton}>
            <Ionicons name="create-outline" size={30} color="black" />
          </TouchableOpacity>
        </View>

        {userData && (
          <View style={styles.userDataContainer}>
            <Text style={styles.userDataText}>Username: {userData.username}</Text>
            <Text style={styles.userDataText}>Email: {userData.email}</Text>
            <Text style={styles.userDataText}>
              Gender: {userData.gender === 0 ? '男性' : '女性'}
            </Text>
            <Text style={styles.userDataText}>Phone Number: {userData.phoneNumber}</Text>
            <View style={styles.authorizationCodeRow}>
        <TouchableOpacity onPress={copyToClipboard} style={styles.copyIcon}>
          <Ionicons name="copy-outline" size={30} color="black" />
        </TouchableOpacity>
        <Text style={styles.userDataText}>家屬授權碼: {userData.uid}</Text>
      </View>
    </View>
        )}
      </View>
    </KeyboardAwareScrollView>
  );
}

const styles = StyleSheet.create({
  scrollView: {
    backgroundColor: '#F5F7FC',
  },
  container: {
    flex: 1,
    paddingHorizontal: 25,
    paddingTop: 85,
    paddingBottom: 30,
    backgroundColor: '#F5F7FC',
    justifyContent: 'flex-start',
    
  },
  titleContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 30,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginLeft:92,
  },
  editButton: {
    padding: 5,
    borderRadius: 10,
    backgroundColor: '#F5F7FC',
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.12,
    shadowRadius: 2,
    elevation: 2,
  },
  userDataContainer: {
    padding: 25,
    backgroundColor: '#ccd9ff',
    borderRadius: 20,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 8,
    },
    shadowOpacity: 0.08,
    shadowRadius: 5,
    elevation: 5,
    width: '100%', // 确保容器宽度为100%
  },
  userDataText: {
    fontSize: 20,
    marginBottom: 20,
    color: 'black',
    flexShrink: 1,  // 确保文本在需要时可以收缩
    width: '95%', // 限制文本宽度
    overflow: 'hidden', // 隐藏超出部分
  },
  authorizationCodeRow: {
    flexDirection: 'row', 
    alignItems: 'center', 
    marginBottom: 10,
  },
  copyIcon: {
    marginRight: 15,
    padding: 8,
    borderRadius: 50,
    backgroundColor: 'white',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
