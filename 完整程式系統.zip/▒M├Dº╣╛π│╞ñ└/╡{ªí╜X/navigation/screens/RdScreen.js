import React, { useState, useEffect } from 'react';
import { View, Text, ActivityIndicator, StyleSheet } from 'react-native';
import { ref as dbRef, onValue, off } from 'firebase/database';
import { database } from '../../config';

export default function RdScreen({ route }) {
    const { itemId } = route.params;
    const [itemDetails, setItemDetails] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const itemDatabaseRef = dbRef(database, `refute/${itemId}`);

        const handleDataChange = snapshot => {
            const data = snapshot.val();
            setItemDetails(data);
            setLoading(false); // 更新 loading 状态一次数据已被接收
        };

        onValue(itemDatabaseRef, handleDataChange);

        return () => {
            off(itemDatabaseRef, 'value', handleDataChange); // 当组件卸载时，移除监听
        };
    }, [itemId]);

    if (loading) {
        return (
            <View style={styles.loadingContainer}>
                <ActivityIndicator size="large" color="#0000ff" />
            </View>
        );
    }

    return (
        <View style={styles.container}>
            {itemDetails ? (
                <>
                    <View style={styles.blueBox}>
                        <Text style={styles.title}>{itemDetails.標題}</Text>
                        <Text style={styles.content}>{itemDetails.內容}</Text>
                    </View>
                </>
            ) : (
                <Text style={styles.noDetails}>No details found for the selected item.</Text>
            )}
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        marginLeft:'5%',
        marginRight:'5%',
        backgroundColor:'#F5F7FC',
    },
    loadingContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#203864', // 设置加载时的背景颜色为蓝色
    },
    blueBox: {
        backgroundColor: '#203864', // 设置蓝色圆框背景颜色
        padding: 20, // 设置内边距
        borderRadius: 25, // 设置边框圆角
    },
    title: {
        fontSize: 26,
        fontWeight: 'bold',
        marginBottom: '5%',
        color: 'white',
        textAlign: 'center',
    },
    content: {
        fontSize: 20,
        color: 'white',
        // textAlign: 'center',
        lineHeight: 30,
    },
    noDetails: {
        fontSize: 16,
    },
    
});
