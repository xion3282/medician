import { StyleSheet } from 'react-native';

export const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#EEEFF1', //內顏色
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20, // 加入 padding 屬性
    borderWidth: 30, // 加入 border 屬性
    borderColor: '#fff', // 設置背景顏色
    borderRadius: 60,
  },
  title: {
    fontSize: 62,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 'auto',
  },
  radioContainer: {
    marginTop: 20,
  },
  radioTitle: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
  },
});
