import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, TextInput } from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import { ref, onValue, off, query, limitToFirst } from 'firebase/database';
import { database } from '../../config';

export default function RefuteScreen({ navigation }) {
    const [data, setData] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredData, setFilteredData] = useState([]);
    const handleItemClick = (id) => {
        navigation.navigate('RdScreen', { itemId: id });
    }

    useEffect(() => {
        const dbRef = ref(database, 'refute/');
        const limitedQuery = query(dbRef, limitToFirst(100));
    
        const handleDataChange = snapshot => {
            const fetchedData = snapshot.val();
            if (fetchedData) {
                const dataArray = Object.keys(fetchedData).map(key => {
                    return {
                        id: key,
                        ...fetchedData[key],
                    };
                });

                setData(dataArray);
                // console.log('Item 標題: ', item.標題);
                // 在這裡進行數據過濾
                if (searchTerm === '') {
                    setFilteredData(dataArray);
                } else {
                    const result = dataArray.filter(item => item.標題 && item.標題.includes(searchTerm));
                    setFilteredData(result);
                   
                }
            }
        };
        
        onValue(limitedQuery, handleDataChange);
    
        return () => {
            off(dbRef, 'value', handleDataChange);
        };
    }, [searchTerm]); // 將 searchTerm 添加為依賴，以便在 searchTerm 改變時重新運行 useEffect
      

    return (
        <View style={styles.container}>
            <TextInput
                style={styles.searchInput}
                value={searchTerm}
                onChangeText={text => setSearchTerm(text)}
                placeholder="輸入闢謠.."
            />
            <ScrollView>
            {filteredData.map(item => {
//    console.log('Item 標題: ', item.標題);
    return (
        <TouchableOpacity key={item.id} onPress={() => handleItemClick(item.id)}>
            <View style={styles.itemContainer}>
            <Text style={styles.text}>{item.標題 ?? '無標題'}</Text>

                {/* <Text style={styles.text}>{item.內容}</Text> */}
            </View>
        </TouchableOpacity>
    );
})}

            </ScrollView>
        </View>
    );
}


const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor:'#F5F7FC',
    },
    searchInput: {
        width: '95%',
        padding: 10,
        borderWidth: 1,
        borderColor: '#ccc',
        marginTop:10,
        marginBottom: 10,
        borderRadius: 5,
    },
    infoIcon: {
        position: 'absolute',
        top: 10,
        left: 10
    },
    searchIcon: {
        position: 'absolute',
        top: 10,
        right: 10
    },
    header: {
        fontSize: 26,
        fontWeight: 'bold',
        marginBottom: 20
    },
    itemContainer: {
        padding: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#ccc'
    },
    text: {
        fontSize: 20,
        marginVertical: 5
    },
    picker: {
        flex: 1,
    },
});

