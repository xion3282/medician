import React, { useState, useEffect } from "react";
import { View, Text, TouchableOpacity, FlatList, StyleSheet, Dimensions } from "react-native";
import { auth, firestore } from "../../config";
import { getFirestore, collection, onSnapshot, doc, updateDoc } from "firebase/firestore";
import { format } from "date-fns";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import CalendarStrip from "react-native-slideable-calendar-strip";

const width = Dimensions.get('window').width;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#ccd9ff",
    padding: 15,
    borderRadius: 15,
    margin: 5,
    marginHorizontal: 10,
  },
  innerContainer: {
    alignContent: "center",
    flexDirection: "column",
  },
  itemHeading: {
    fontWeight: "bold",
    color: "#002080",
    fontSize: 25,
  },
  itemTime: {
    fontWeight: "400",
    color: "#00134d",
    fontSize: 20,
  },
  itemTimeContainer: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginTop: 5,
  },
  circle: {
    width: 30,
    height: 30,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: "gray",
    alignItems: "center",
    justifyContent: "center",
    marginLeft: 10,
  },
  checkMark: {
    fontSize: 25,
    color: "red",
  },
});

export default function HomeScreen({ navigation }) {
  const [selectedDate, setSelectedDate] = React.useState(new Date());
  const [users, setUsers] = useState([]);
  const [selectedCircles, setSelectedCircles] = useState({});

  const user = auth.currentUser;
  const userDocRef = doc(firestore, "users", user.uid);
  const alertDataCollectionRef = collection(userDocRef, "alertData");

  const handleIconClick = async (id, index) => {
    const newSelectedCircles = {
      ...selectedCircles,
      [`${id}_${index}`]: {
        isSelected: !selectedCircles[`${id}_${index}`]?.isSelected,
        timestamp: new Date(),
      },
    };

    setSelectedCircles(newSelectedCircles);

    try {
      // 更新 Firestore 中的文檔，添加所選時間
      const docRef = doc(alertDataCollectionRef, id);
      await updateDoc(docRef, {
        selectedCircles: newSelectedCircles,
      });
    } catch (error) {
      console.error("錯誤更新文檔：", error);
      // 處理錯誤
    }
  };

  useEffect(() => {
    const fetchUsers = () => {
      onSnapshot(alertDataCollectionRef, (snapshot) => {
        const users = [];
        snapshot.forEach((doc) => {
          const {
            Mname,
            Msum,
            selectedTimes, // 使用Firestore中的selectedTimes字段
            startD,
            endD,
            selectedCircles, // 添加selectedCircles字段
          } = doc.data();
          users.push({
            id: doc.id,
            Mname,
            Msum,
            selectedTimes, // 分配Firestore中的selectedTimes字段
            startD,
            endD,
            selectedCircles, // 添加selectedCircles字段
          });
        });
        setUsers(users);
      });
    };

    fetchUsers();
  }, [user.uid]);

  return (
    <View style={{ flex: 1, backgroundColor: "#f5f7fc" }}>
      <View>
        <CalendarStrip
          selectedDate={selectedDate}
          onPressDate={(date) => {
            setSelectedDate(date);
          }}
          onPressGoToday={(today) => {
            setSelectedDate(today);
          }}
          markedDate={[
            "2018-05-04",
            "2018-05-15",
            "2018-06-04",
            "2018-05-01",
          ]}
          weekStartsOn={1}
          dateNumberStyle={{ color: "white", fontSize: 30 }}
        />
        <View
          style={{
            width,
            flexDirection: "row",
            alignItems: "center",
            justifyContent: "space-around",
          }}
        ></View>
      </View>
      <KeyboardAwareScrollView>
        <FlatList
          style={{ flex: 1 }}
          data={users}
          numColumns={1}
          renderItem={({ item }) => (
            <TouchableOpacity
              style={styles.container}
              // onPress={() => {
              //   navigation.navigate("DetailsScreen", {
              //     itemId: item.id,
              //     itemName: item.Mname,
              //     itemSD: item.startD,
              //     itemED: item.endD,

              //   });
              // }}
            >
              <View style={styles.innerContainer}>
                <Text style={styles.itemHeading}>{item.Mname}</Text>
                {item.selectedTimes && Array.isArray(item.selectedTimes) && item.selectedTimes.map((timestamp, index) => (
    <View style={styles.itemTimeContainer} key={index}>
        <Text style={styles.itemTime}>
            {timestamp && timestamp.toDate ? format(timestamp.toDate(), "hh:mm a") : ""}
        </Text>
        {selectedCircles[`${item.id}_${index}`]?.isSelected && (
            <View style={styles.timestampContainer}>
                <Text style={styles.timestampText}>
                    {format(
                        selectedCircles[`${item.id}_${index}`].timestamp,
                        "hh:mm a"
                    )}
                </Text>
                <TouchableOpacity
                    onPress={() => handleIconClick(item.id, index)}
                    style={styles.circle}
                >
                    <Text style={styles.checkMark}>✔</Text>
                </TouchableOpacity>
            </View>
        )}
        {!selectedCircles[`${item.id}_${index}`]?.isSelected && (
            <TouchableOpacity
                onPress={() => handleIconClick(item.id, index)}
                style={styles.circle}
            />
        )}
    </View>
))}
              </View>
            </TouchableOpacity>
          )}
        />
      </KeyboardAwareScrollView>
    </View>
  );
}
