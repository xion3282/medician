import { StyleSheet } from 'react-native';

export const buttonStyles = StyleSheet.create({  
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',    
  },
  Button: {
    backgroundColor: '#203864',
    padding: 10,
    borderRadius: 10,
    width: '50%',
    alignItems: 'center',
    marginBottom: 'auto',
  },
  ButtonText: {
    color: '#fff',
    fontSize: 32,
    textAlign: 'center',
    marginBottom: 'auto'
  },
  button: {
    backgroundColor: '#D0D0D0',
    padding: 10,
    borderRadius: 10,
    width: '50%',
    marginTop: 5,
     flexDirection: 'row',
    alignItems: 'flex-start',
     justifyContent: 'center',
    
  },
  buttonText: {
    color: '#000',
    fontSize: 32,
    textAlign: 'center',
  },
});
