import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, ScrollView, StyleSheet, TextInput,Image} from 'react-native';
import { AntDesign } from '@expo/vector-icons';
import { ref, onValue, off, query, limitToFirst } from 'firebase/database';
import { database } from '../../config';


export default function MedScreen({ navigation }) {
    const [data, setData] = useState([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [filteredData, setFilteredData] = useState([]);
    const handleItemClick = (id) => {
        navigation.navigate('DmScreen', { itemId: id });
    }

    useEffect(() => {
        const dbRef = ref(database, 'med/');
        const limitedQuery = query(dbRef, limitToFirst(1000));
    
        const handleDataChange = snapshot => {
            const fetchedData = snapshot.val();
            // console.log("Fetched data:", fetchedData); // 添加這一行來看資料

            if (fetchedData) {
                const dataArray = Object.keys(fetchedData).map(key => ({
                    id: key,
                    ...fetchedData[key],
                }));
                setData(dataArray);
            }
        };
    
        onValue(limitedQuery, handleDataChange, (error) => {
            console.error("Firebase read failed:", error);
        });
    
        // Clean-up function to detach the listener
        return () => {
            off(dbRef, 'value', handleDataChange);
        };
    }, []);

    useEffect(() => {
        
        if (searchTerm === '') {
            setFilteredData(data);
        } else {
            const result = data.filter(item => 
                (item.中文品名_x && item.中文品名_x.includes(searchTerm)) ||
                (item.英文品名_x && item.英文品名_x.includes(searchTerm))
            );
            setFilteredData(result);
        }
    }, [data, searchTerm]);

    return (
        <View style={styles.container}>
           
            <TextInput
                style={styles.searchInput}
                value={searchTerm}
                onChangeText={text => setSearchTerm(text)}
                placeholder="輸入藥品名.."
            />
            <ScrollView>
            {filteredData.map(item => (
                <TouchableOpacity key={item.id} onPress={() => handleItemClick(item.id)}>
                    <View style={styles.itemContainer}>
                        <Text style={styles.text}>{item.中文品名_x}</Text>
                        <Text style={styles.text}>{item.英文品名_x}</Text>
                    </View>
                </TouchableOpacity>
            ))}

            </ScrollView>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: '#F5F7FC'
    },
    searchInput: {
        width: '95%',
        padding: 10,
        borderWidth: 1,
        borderColor: '#ccc',
        marginTop:10,
        marginBottom: 10,
        borderRadius: 5,
    },
    infoIcon: {
        position: 'absolute',
        top: 10,
        left: 10
    },
    searchIcon: {
        position: 'absolute',
        top: 10,
        right: 10
    },
    header: {
        fontSize: 26,
        fontWeight: 'bold',
        marginBottom: 20
    },
    itemContainer: {
        padding: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#ccc'
    },
    text: {
        fontSize: 20,
        marginVertical: 5
    },
    picker: {
        flex: 1,
    },
});

