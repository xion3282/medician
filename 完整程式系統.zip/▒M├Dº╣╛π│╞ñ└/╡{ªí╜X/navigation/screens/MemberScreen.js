import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { signOut } from 'firebase/auth';
import { auth } from '../../config';  // 確保這是您Firebase Auth的正確配置路徑

export default function MemberScreen({ navigation }) {
  const handleLogout = () => {
    signOut(auth)
      .then(() => {
        Alert.alert("登出成功!"); // 提示用戶登出成功
        navigation.navigate('Login');
      })
      .catch(error => {
        Alert.alert("登出失敗", error.message); // 提示用戶發生錯誤
      });
  }

  return (
    <View style={styles.container}>
      <View style={styles.contentContainer}>
        <View style={styles.iconTextContainer}>
          <TouchableOpacity style={styles.settingButton} onPress={() => navigation.navigate('DataMember')}>
            <Ionicons name="person-circle-outline" size={60} color="black" style={styles.icon} />
            <Text style={styles.subHeading}>會員資料</Text>
          </TouchableOpacity>
        </View>

        <TouchableOpacity style={styles.settingButton} onPress={() => navigation.navigate('設定')}>
          <Ionicons name="people-circle-outline" size={60} color="black" style={styles.icon} />
          <Text style={styles.subHeading}>家屬設定</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.settingButton} onPress={() => navigation.navigate('SrScreen')}>
          <Ionicons name="document-text-outline" size={60} color="black" style={styles.icon} />
          <Text style={styles.subHeading}>資料來源</Text>
        </TouchableOpacity>

         <TouchableOpacity style={styles.settingButton} onPress={handleLogout}>
      <Ionicons name="ios-log-out-outline" size={60} color="black" style={styles.icon} />
      <Text style={styles.subHeading}>登出</Text>
    </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 40,
    paddingVertical: 180,
    borderRadius: 5,
    backgroundColor: '#F5F7FC',
  },
  contentContainer: {
    alignItems: 'center',
  },
  iconTextContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  icon: {
    marginRight: 10,
  },
  heading: {
    fontSize: 25,
    fontWeight: 'bold',
  },
  subHeading: {
    fontSize:25,
    fontWeight: 'bold',
  },
  settingButton: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 55,
  },
});
