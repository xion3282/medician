import * as React from 'react';
import { View, Text, TouchableOpacity } from 'react-native';

export default function HdAddScreen({ navigation, route }) {
  const { selectedDate } = route.params;

  return (
    <View style={{ flex: 1, justifyContent: 'flex-start', alignItems: 'center',backgroundColor: "#f5f7fc"  }}>
      <TouchableOpacity onPress={() => navigation.navigate('新增身高體重', { selectedDate: selectedDate })}
        style={{ 
          backgroundColor: '#203864', 
          padding: 30, 
          paddingLeft: '12.5%', 
          paddingRight: '12.5%',
          marginTop: '13%',
          marginBottom: '10%',
          borderRadius:10 }}>

        <Text style={{ 
          color: 'white', 
          fontSize: 32 }}>身高體重</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('新增血壓', { selectedDate: selectedDate })}
        style={{ 
          backgroundColor: '#203864', 
          padding: 30, 
          paddingLeft: '20%', 
          paddingRight: '20%',  
          marginBottom: '10%',
          borderRadius:10
        }}>
        <Text style={{ 
          color: 'white', 
          fontSize: 32  }}>血壓</Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={() => navigation.navigate('新增血糖', { selectedDate: selectedDate })}
        style={{ 
          backgroundColor: '#203864', 
          padding: 30, 
          paddingLeft: '20%', 
          paddingRight: '20%',  
          marginBottom: '10%',
          borderRadius:10
        }} >
        <Text style={{ color: 'white', fontSize: 32  }}>血糖
        </Text>
      </TouchableOpacity>
    </View>
  );
}

