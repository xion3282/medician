import * as React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image } from 'react-native';
import Ionicons from 'react-native-vector-icons/Ionicons';
import { AntDesign } from '@expo/vector-icons';
import { firebaseApp } from '../../config';
import { getFirestore, collection, doc, getDoc } from 'firebase/firestore';

export default function DetailsScreen({ route, navigation }) {
  const { itemId, itemName,uid} = route.params;
  const [documentData, setDocumentData] = React.useState(null);


  const trueCount = documentData && documentData.selectedCircles
  ? Object.values(documentData.selectedCircles).filter(item => item.isSelected).length
  : 0;

const remainingDose = documentData?.Msum - (documentData?.Mevery * trueCount);

  // 使用 ID 从 Firebase Firestore 查询数据
  React.useEffect(() => {
    async function fetchDocumentData() {
      const db = getFirestore(firebaseApp);
      const docRef = doc(db, 'users', uid, 'alertData', itemId);

      try {
        const docSnapshot = await getDoc(docRef);

        if (docSnapshot.exists()) {
          setDocumentData(docSnapshot.data());
        } else {
          console.log('Document does not exist');
        }
      } catch (error) {
        console.error('Error getting document:', error);
      }
    }

    fetchDocumentData();
  }, [itemId, uid]);

  return (
    <ScrollView>
      <View style={{ flex: 1, marginTop: 30 }}>
        <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
          <Text style={{ fontSize: 40, fontWeight: 'bold', marginLeft: 10, marginBottom: 60 }}>{itemName}</Text>
          <TouchableOpacity
            onPress={() => {
              navigation.navigate('EditAlertScreen', { itemId, uid });
              console.log(itemId, 'pressed');
            }}
            style={{ position: 'absolute', top: 10, right: 10 }}>
            <AntDesign name="form" size={35} color="black" />
          </TouchableOpacity>
        </View>
        <View style={styles.centeredText}>
        <Image
          source={{ uri: documentData?.imageUrl }}
          style={{ width: 200, height: 200 }}  // 您可以根據需要調整尺寸
        />
        </View>
        <Text style={styles.centeredText}>總劑量</Text>
        <Text style={styles.centeredText}>{documentData?.Msum}{documentData?.Munit}</Text>
        <Text style={styles.centeredText}>每次服用量</Text>
        <Text style={styles.centeredText}>{documentData?.Mevery}{documentData?.Munit}</Text>
        <Text style={styles.centeredText}>剩餘劑量</Text>
        <Text style={styles.centeredText2}>{remainingDose}{documentData?.Munit}</Text>
        <Text style={styles.centeredText}>開始時間</Text>
        <Text style={styles.centeredText}>{documentData?.startD.toDate().toLocaleDateString()}</Text>
        <Text style={styles.centeredText}>結束時間</Text>
        <Text style={styles.centeredText}>{documentData?.endD.toDate().toLocaleDateString()}</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  centeredText: {
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
    justifyContent: 'center',
    alignItems: 'center',
  },
  centeredText2: {
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
    justifyContent: 'center',
    alignItems: 'center',
    color: 'red',
  },

});
