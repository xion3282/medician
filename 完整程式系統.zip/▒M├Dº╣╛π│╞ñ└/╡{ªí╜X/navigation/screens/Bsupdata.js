import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import PickerSelect from 'react-native-picker-select';
import { firestore, auth } from '../../config';
import { doc, updateDoc } from '@firebase/firestore';

const formatDate = (date) => {
  const offset = date.getTimezoneOffset();
  const localDate = new Date(date.getTime() - (offset * 60 * 1000));
  return localDate.toISOString().split('T')[0];
};

const pickerSelectStyles = StyleSheet.create({
  inputIOS: {
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 18, // 調整左側內邊距
    borderWidth: 0,
    borderRadius: 10,
    color: 'black',
    paddingRight: 20,
    paddingLeft: 15, // Remove left padding for the placeholder
    marginRight: 5, // Move the select box to the left
    backgroundColor: '#203864',
    color: 'white',
    marginTop: 2,
  },
  inputAndroid: {
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 18, // 調整左側內邊距
    borderWidth: 0,
    borderRadius: 10,
    color: 'black',
    paddingRight: 20,
    paddingLeft: 15, // Remove left padding for the placeholder
    marginRight: 5, // Move the select box to the left
    backgroundColor: '#203864',
    color: 'white',
    marginTop: 2,
  },
});

export default function Bsupdata({ route, navigation }) {
  const { data, selectedDate } = route.params;
  const [glucose, setGlucose] = useState(data.glucose);
  const [mealTime, setMealTime] = useState(data.mealTime);

  const handleUpdate = async () => {
    try {
      const user = auth.currentUser;
      if (!user) return;

      const uid = user.uid;
      const userDocRef = doc(firestore, 'users', uid);
      const bsDocRef = doc(userDocRef, 'BloodSugar', data.id);

      await updateDoc(bsDocRef, {
        glucose: glucose,
        mealTime: mealTime,
        createdBS: formatDate(selectedDate),
      });

      Alert.alert("更新成功");
      navigation.goBack(); // 返回到 HdScreen 畫面
    } catch (error) {
      console.error("更新錯誤: ", error);
      Alert.alert("更新錯誤", "請稍後再試");
    }
  };

  return (
    <View style={{ flex: 1 }}>
      <View style={styles.inputContainer}>
        <Text style={styles.bloodSugarText}>血糖</Text>
        <View style={styles.inputRow}>
          <PickerSelect
            value={mealTime}
            onValueChange={setMealTime}
            items={[
              { label: '飯前', value: '飯前' },
              { label: '飯後', value: '飯後' },
            ]}
            style={pickerSelectStyles}
            useNativeAndroidPickerStyle={false}
            placeholder="" // Remove the placeholder text
          />
          <TextInput
            value={glucose.toString()}
            onChangeText={setGlucose}
            style={styles.input}
            keyboardType="numeric"
            placeholder="輸入血糖"
            maxLength={6}
          />
        </View>
        <View style={styles.buttonContainer}>
          <TouchableOpacity onPress={() => navigation.navigate('健康日誌')} style={styles.cancelButton}>
            <Text style={styles.buttonText}>取消</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={handleUpdate} style={styles.addButton}>
            <Text style={styles.buttonText}>更新</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  inputContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 10,
    borderWidth: 32,
    borderColor: '#535E6D',
  },
  bloodSugarText: {
    fontSize: 40,
    fontWeight: 'bold',
    marginBottom: 22,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  input: {
    height: 50,
    borderColor: 'gray',
    width: 165,
    borderWidth: 1,
    borderRadius: 10,//框的圓弧度
    marginBottom: 15,
    paddingHorizontal: 50,
    textAlign: 'center',
    fontSize: 25,
  },
  unitText: {
    fontSize: 22,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginTop: 20,
  },
  addButton: {
    backgroundColor: '#203864',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
  },
  cancelButton: {
    backgroundColor: '#BFBFBF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginRight: 50,
    marginLeft: 10,
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 20,
  },
});
