import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Image, TextInput,ScrollView,Keyboard} from 'react-native';
import { Camera } from 'expo-camera';
import * as ImagePicker from 'expo-image-picker';
import ModalDropdown from 'react-native-modal-dropdown';
import DateTimePicker from '@react-native-community/datetimepicker';
import { firebaseApp } from '../../config';
import { getFirestore, collection, doc, getDoc, updateDoc, deleteDoc, serverTimestamp } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';
import * as Notifications from 'expo-notifications';


export default function EditAlertScreen({route,navigation }) {
  const { itemId, uid }  = route.params;
  const db = getFirestore(firebaseApp);
  const alertDataRef = doc(db, 'users', uid, 'alertData', itemId);
 
 const [addMname,setMname] = useState('');
 const [addMsum, setMsum] = useState('');
 const [addMevery, setMevery] = useState('');

  const [documentData, setDocumentData] = React.useState(null);
  const syncUnits = (selectedUnit) => {
    setUnitTotal(selectedUnit);
    setUnitPerDose(selectedUnit);
  };
  const [unitTotal, setUnitTotal] = useState("包");
  const [unitPerDose, setUnitPerDose] = useState("包");

  const uploadImageToFirebase = async (imageUri) => {
    const storage = getStorage(firebaseApp);
    const fileName = imageUri.split('/').pop();
    const imageRef = ref(storage, 'uploads/' + fileName);

    const response = await fetch(imageUri);
    const blob = await response.blob();

    await uploadBytes(imageRef, blob);

    const downloadUrl = await getDownloadURL(imageRef);
    return downloadUrl;
};


  useEffect(() => {
    getDoc(alertDataRef)
      .then((docSnapshot) => {
        if (docSnapshot.exists()) {
          const data = docSnapshot.data();
          if(data.imageUrl) {
            setImage(data.imageUrl); // 设置imageUrl为image state
        }
          setMsum(data.Msum || '');
          setMname(data.Mname || '');
          setMevery(data.Mevery || '');
          setUnitTotal(data.Munit || '');
          setStartDate(data.startD.toDate() || new Date());
          setEndDate(data.endD.toDate() || new Date());
          setSelectedTime(data.selectedTime.toDate() || new Date());
          setSelectedTime1(data.selectedTime1.toDate() || new Date());
          setSelectedTime2(data.selectedTime2.toDate() || new Date());
          
        } else {
          console.log('Document does not exist');
        }
      })
      .catch((error) => {
        console.log('Error getting document:', error);
      });
  }, [itemId, uid]);

const DeletAdd = () => {
  deleteDoc(alertDataRef)
    .then(() => {
      console.log('Deleted successfully');
      setMname('');
    setMsum('');
    setMevery('');
    setSelectedFrequency('1');
    setStartDate(new Date());
    setEndDate(new Date());
    Keyboard.dismiss();
    navigation.navigate('MalertScreen');
    })
    .catch((error) => {
      console.error('Error deleting document:', error);
    });
};

const [timePickers, setTimePickers] = useState([
  { value: new Date(), show: false },
  { value: new Date(), show: false },
  { value: new Date(), show: false },
  { value: new Date(), show: false },

]);


const updateField = async () => {
  if (addMname && addMsum && addMevery && addMname.length > 0) {
    let imgUrl = null;

    if (image) {
      imgUrl = await uploadImageToFirebase(image);
    }

    // Create an array to hold the selected times
    const selectedTimes = timePickers
    .slice(0, parseInt(selectedFrequency))
    .map((picker, index) => picker.value);

    const timestamp = serverTimestamp();
    const dataToUpdate = {
      Mname: addMname,
      Msum: addMsum,
      Munit:unitTotal,
      Mevery: addMevery,
      frequency: selectedFrequency,
      startD: startDate,
      endD: endDate,
      selectedTimes: selectedTimes, // Use an array to store selected times as timestamps
      updatedAt: timestamp,
      ...(imgUrl && { imageUrl: imgUrl })
    };

    updateDoc(alertDataRef, dataToUpdate)
      .then(async () => {
        console.log('Updated successfully');
        setMname('');
        setMsum('');
        setMevery('');
        setUnitTotal('包');
        setSelectedFrequency('1');
        setStartDate(new Date());
        setEndDate(new Date());
        setSelectedTime(new Date());

        Keyboard.dismiss();
         selectedTimes.forEach(async (time) => {
      await scheduleNotification(addMevery,unitTotal,addMname,time,selectedFrequency, startDate, endDate);
    });

    navigation.navigate('MalertScreen');


  })
  .catch((error) => {
    console.error('Error updating document:', error);
  });
 }
 };
 const scheduleNotification = async (Mevery,Munit,Mname,time, frequency, startDate, endDate) => {
  // Request permissions
  const { status } = await Notifications.requestPermissionsAsync();
  if (status !== 'granted') {
    alert('通知权限被拒绝！');
    return;
  }

  const secondsInADay = 24 * 60 * 60; // 一天的秒数

  let currentDate = new Date(startDate); // 从开始日期开始
  endDate = new Date(endDate);
  while (currentDate <= endDate) {
    const notificationTime = new Date(
      currentDate.getFullYear(),
      currentDate.getMonth(),
      currentDate.getDate(),
      time.getHours(),
      time.getMinutes(),
      time.getSeconds()
    );

    const titleSuffix = Mname.includes('藥') ? '' : '藥';
    const notificationTitle = `${Mevery}${Munit}${Mname}${titleSuffix}`;
  
      if (notificationTime > new Date()) {
        const notificationId =// 只安排未来的通知
        await Notifications.scheduleNotificationAsync({
          content: {
            title: notificationTitle,
            body: '服藥時間到了!!'
          },
          trigger: notificationTime,
        });
      }

    currentDate.setDate(currentDate.getDate() + parseInt(frequency)); // 移到下一天
  }
};


 const [selectedFrequency, setSelectedFrequency] = useState('1');


  const [hasPermission, setHasPermission] = useState(null);
  const [image, setImage] = useState(null);
  const [useCamera, setUseCamera] = useState(false);
  const cameraRef = useRef(null);
  const [type, setType] = useState(Camera.Constants.Type.back);

  const [startDate, setStartDate] = useState(new Date());
  const [endDate, setEndDate] = useState(new Date());
  const [showStartDatePicker, setShowStartDatePicker] = useState(false);
  const [showEndDatePicker, setShowEndDatePicker] = useState(false);

 
  const handleStartDateChange = (event, selectedDate) => {
    const currentDate = selectedDate || startDate;
    setShowStartDatePicker(false);
    setStartDate(currentDate);
  };

  const handleEndDateChange = (event, selectedDate) => {
    const currentDate = selectedDate || endDate;
    setShowEndDatePicker(false);
    setEndDate(currentDate);
  };

  const showStartDatePickers = () => {
    setShowStartDatePicker(true);
  };

  const showEndDatePickers = () => {
    setShowEndDatePicker(true);
  };

  const [selectedTime, setSelectedTime] = useState(new Date());
  const [selectedTime1, setSelectedTime1] = useState(new Date());
  const [selectedTime2, setSelectedTime2] = useState(new Date());
  // const [showTimePicker, setShowTimepicker] = useState(false);
  // const [showTimePicker1, setShowTimepicker1] = useState(false);
  // const [showTimePicker2, setShowTimepicker2] = useState(false);

  const handleTimeChange = (index, selected) => {
    setTimePickers(timePickers => timePickers.map((picker, i) => 
      i === index ? { ...picker, value: selected || picker.value, show: false } : picker
    ));
  };
 
  // const showTimePickers = () => {
  //   setShowTimepicker(true);
  // };

  // const handleTimeChange1 = (event, selected1) => {
  //   const currentTime = selected1 || selectedTime1;
  //   setSelectedTime1(currentTime);
  //   setShowTimepicker1(false);
  // };
 
  // const showTimePickers1 = () => {
  //   setShowTimepicker1(true);
  // };

  // const handleTimeChange2 = (event, selected2) => {
  //   const currentTime = selected2 || selectedTime2;
  //   setSelectedTime2(currentTime);
  //   setShowTimepicker2(false);
  // };
 
  // const showTimePickers2 = () => {
  //   setShowTimepicker2(true);
  // };

  useEffect(() => {
    Notifications.setNotificationHandler({
      handleNotification: async () => ({
        shouldShowAlert: true,
        shouldPlaySound: false,
        shouldSetBadge: false,
      }),
    });
    (async () => {
      const { status } = await Camera.requestCameraPermissionsAsync();
      setHasPermission(status === 'granted');
    })();
  }, []);

  if (hasPermission === null) {
    return <View />;
  }
  if (hasPermission === false) {
    return <Text>No access to camera</Text>;
  }

  const takePicture = async () => {
    if (cameraRef) {
      console.log('in take picture');
      try {
        let photo = await cameraRef.current.takePictureAsync({
          allowsEditing: true,
          aspect: [4, 3],
          quality: 1,
        });
        return photo;
      } catch (e) {
        console.log(e);
      }
    }
  };

  const pickImage = async () => {
    let result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.All,
      allowsEditing: true,
      aspect: [4, 3],
      quality: 1,
    });

    if (!result.cancelled) {
      return result;
    }
  };
  

  return (
    <ScrollView>
    <View style={styles.container}>
      <View style={{ flex: 1, marginTop: 5, backgroundColor: '#f5f7fc', alignItems: 'center', borderTopLeftRadius: 20, borderTopRightRadius: 20, borderBottomLeftRadius: 20, borderBottomRightRadius: 20, overflow: 'hidden' }}>
        <View style={{ height: 600, width: 600,alignItems: 'center',marginTop:5 }}>
          <Text style={{ fontSize: 20, color: 'black' }}>名稱</Text>
          <TextInput
            style={styles.TextInput3}
            backgroundColor='white'
            placeholder="請輸入名稱"
            maxLength={10}
            onChangeText={(Mname) => setMname(Mname)}
            value={addMname}
          />

          <Text style={{ fontSize: 20, color: 'black',marginTop:5}}>總劑量</Text>
          <View style={styles.buttonRow1}>
          <TextInput
            style={styles.TextInput}
            backgroundColor='white'
            placeholder="請輸入數量"
            keyboardType='numeric'
            maxLength={3}
            onChangeText={(Msum) => setMsum(Msum)}
            value={addMsum}
          />
          <ModalDropdown 
    options={['包', '顆']} 
    dropdownTextStyle={{ fontSize: 20 }} 
    defaultValue={unitTotal} 
    renderButtonText={(rowData) => {
        syncUnits(rowData);
        return <Text style={{ fontSize: 20 }}>{rowData}</Text>;
    }}
    selectedValue={unitTotal}
/></View>
           
          <Text style={{ fontSize: 20, color: 'black',marginTop:5}}>每次服用量</Text>
          <View style={styles.buttonRow1}>
          <TextInput
            style={styles.TextInput}
            backgroundColor='white'
            placeholder="請輸入數量"
            keyboardType='numeric'
            maxLength={2}
            onChangeText={(Mevery) => setMevery(Mevery)}
            value={addMevery}
          />
          <Text style={{ fontSize: 20, color: 'black' }}>{unitTotal}</Text></View>
          <Text style={{ fontSize: 20, color: 'black', marginTop: 5 }}>每天服藥次數</Text>
          <ModalDropdown
          options={['1', '2', '3', '4']}
          dropdownTextStyle={{ fontSize: 20 }}
          defaultValue={selectedFrequency.toString()} // 將選中的值轉為字符串
          renderButtonText={(rowData) => <Text style={{ fontSize: 20 }}>{rowData}</Text>}
          onSelect={(index, value) => setSelectedFrequency(value)}
         />
          {timePickers.slice(0, parseInt(selectedFrequency)).map((picker, index) => (
            <View key={index} style={styles.buttonRow2}>
              <TouchableOpacity onPress={() => setTimePickers(timePickers => timePickers.map((p, i) => 
                i === index ? { ...p, show: true } : p
              ))}>
                <Text style={styles.TextInput2}>
                  {picker.value.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                </Text>
              </TouchableOpacity>
              {picker.show && (
                <DateTimePicker
                  value={picker.value}
                  mode="time"
                  display="default"
                  onChange={(event, selected) => handleTimeChange(index, selected)}
                />
              )}
            </View>
          ))}

   


          <Text style={{ fontSize: 20, color: 'black' }}>開始日期</Text>
          <TouchableOpacity onPress={showStartDatePickers}>
            <Text  style={styles.TextInput1}>{startDate.toLocaleDateString()}</Text>
          </TouchableOpacity>
          {showStartDatePicker && (
            <DateTimePicker
              value={startDate}
              mode="date"
              display="default"
              onChange={handleStartDateChange}
            />
          )}
          <Text style={{ fontSize: 20, color: 'black' }}>結束日期</Text>
          <TouchableOpacity onPress={showEndDatePickers}>
            <Text style={styles.TextInput1}>{endDate.toLocaleDateString()}</Text>
          </TouchableOpacity>
          {showEndDatePicker && (
            <DateTimePicker
              value={endDate}
              mode="date"
              display="default"
              onChange={handleEndDateChange}
            />
          )}

        </View>
        <View
          style={{
            flex: 2,
            alignItems: 'flex-end',
            justifyContent: 'center',
          }}>
          {useCamera ? (
            <View style={{ alignItems: 'center', justifyContent: 'center' }}>
            <Camera style={styles.camera} type={type} ref={cameraRef}>
                <View style={styles.buttonContainer}>
                  <TouchableOpacity
                    style={styles.button}
                    onPress={() => {
                      setUseCamera(false);
                    }}>
                    <Text style={styles.text}>取消</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={styles.button}
                    onPress={() => {
                      setType(
                        type === Camera.Constants.Type.back
                          ? Camera.Constants.Type.front
                          : Camera.Constants.Type.back
                      );
                    }}>
                    <Text style={styles.text}>翻轉</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.button]}
                    onPress={async () => {
                      console.log('in take pic');
                      const r = await takePicture();
                      setUseCamera(false);
                      if (!r.cancelled) {
                        setImage(r.uri);
                      }
                      console.log('response', JSON.stringify(r));
                    }}>
                    <Text style={styles.text}>拍照</Text>
                  </TouchableOpacity>
                </View>
              </Camera>
            </View>
          ) : (
              <View style={{ width: '100%', marginTop: '-20%' }}>
                <View
                  style={{
                    flexDirection: 'row',
                  }}>
                  <TouchableOpacity
                    style={[styles.button]}
                    onPress={async () => {
                      console.log('in pick photo');
                      const r = await pickImage();
                      if (!r.cancelled) {
                        setImage(r.uri);
                      }
                      console.log('response', JSON.stringify(r));
                    }}>
                  <Text style={styles.text}>圖庫</Text>
                  </TouchableOpacity>
                  <TouchableOpacity
                    style={[styles.button]}
                    onPress={async () => {
                      console.log('in pick camera');
                      setUseCamera(true);
                    }}>
                    <Text style={styles.text}>拍照</Text>
                  </TouchableOpacity>
                </View>
                <View style={{ width: '100%', alignItems: 'center' }}>
                  {image ? (
                    <Image
                      source={{ uri: image }}
                      style={{ width: 200, height: 200, backgroundColor: '#ccd9ff' }}
                    />
                  ) : (
                    <View style={{ width: 200, height: 200, backgroundColor: '#ccd9ff' }} />
                  )}
                </View>
              </View>
            )}
        </View>
        <View style={styles.buttonRow}>
        <TouchableOpacity
            style={styles.button1}
            onPress={() => {
              setUseCamera(false);
              navigation.navigate('MalertScreen'); 
            }}>
            <Text style={styles.text}>取消</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.button1]} 
            onPress={() => {
             DeletAdd(); 
             navigation.navigate('MalertScreen'); 
          }}>
            <Text style={styles.text}>刪除</Text>
            </TouchableOpacity>
            <TouchableOpacity style={[styles.button]} onPress={updateField}>
            <Text style={styles.text}>更新</Text>
            </TouchableOpacity>
            </View>
      </View>
    </View>
    </ScrollView>
);
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'space-between',
    backgroundColor: '#fff',
    padding: 10,
    // margin: 1,
  },
  camera: {
    width: 200,
    height: 200,
  },
  buttonContainer: {
    flexDirection: 'row',
    minWidth: '50%',
    flex: 1
  },
  button: {
    flex: 0.5,
    alignItems: 'center',
    justifyContent: 'center',
    width: 100,
    height: 40,
    margin: 10,
    backgroundColor: '#203864',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20
  },
  button1: {
    flex: 0.5,
    alignItems: 'center',
    justifyContent: 'center',
    width: 100,
    height: 40,
    margin: 10,
    backgroundColor: '#BFBFBF',
    borderTopLeftRadius: 20,
    borderTopRightRadius: 20,
    borderBottomLeftRadius: 20,
    borderBottomRightRadius: 20
  },
  text: {
    fontSize: 18,
    color: 'white',
    fontWeight: 'bold', 
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 20,
  },
  buttonRow2: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginVertical: 10,
    marginRight:10,
    marginLeft:10,
  },
  buttonRow1: {
    flexDirection: 'row',
    // justifyContent: 'space-between',
    // marginVertical: 10,
    alignItems: 'center',
  },
  TextInput:{
    height: 40,
     borderRadius: 10, 
     fontSize: 20,
     width:200,
  },
  TextInput1:{
    marginVertical: 5,
    height: 30,
     borderRadius: 10, 
     fontSize: 20,
     width:200,
     alignItems:'center',
     backgroundColor:'white',
     borderTopLeftRadius: 20,
     borderTopRightRadius: 20,
     borderBottomLeftRadius: 20,
     borderBottomRightRadius: 20,
      overflow: 'hidden'
  },
  TextInput2:{
    // marginVertical: 5,
    height: 30,
     borderRadius: 10, 
     fontSize: 20,
     width:90,
     alignItems:'center',
     backgroundColor:'white',
     borderTopLeftRadius: 20,
     borderTopRightRadius: 20,
     borderBottomLeftRadius: 20,
     borderBottomRightRadius: 20,
    overflow: 'hidden'
  },
  TextInput3:{
    height: 40,
     borderRadius: 10, 
     fontSize: 20,
     width:200,
     marginTop:5
  },
});

