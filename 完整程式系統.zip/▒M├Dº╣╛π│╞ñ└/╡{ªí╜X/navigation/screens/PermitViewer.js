import React from 'react';
import { Button, Linking } from 'react-native';

const PermitViewer = ({ downloadUrl }) => {
  const handlePress = async () => {
    const supported = await Linking.canOpenURL(downloadUrl);

    if (supported) {
      await Linking.openURL(downloadUrl);
    } else {
      console.log(`Don't know how to open this URL: ${downloadUrl}`);
    }
  };

  return <Button title="Open PDF in Browser" onPress={handlePress} />;
};

export default PermitViewer;
