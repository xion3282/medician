import React,{useState}from 'react';
import { StyleSheet,Text,View,Button,Image,TextInput, TouchableOpacity } from 'react-native';
import { useNavigation } from '@react-navigation/native';
import{auth}from '../../config';
import { signInWithEmailAndPassword } from 'firebase/auth'; 
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view'
import yourImage from '../../assets/ima.png';

export default function LoginScreen() {

        const navigation = useNavigation();
        const [email, setEmail] = useState('');
        const [password, setPassword] = useState('');
      
        const  handleSubmit = async () => {
            if(email&&password){
              try{
                  await signInWithEmailAndPassword(auth,email,password);
              }catch(err){
                console.log('got error:',err.message);
              }
            }
          
         }
    
    return (
       
        <View style={styles.header}>
            <KeyboardAwareScrollView style={{backgroundColor:'#F5F7FC'}}>
                <View>
                <Image source={yourImage} style={styles.imageStyle} />
                < Text style={{ fontSize: 80, fontWeight: 'bold', textAlign: 'center', color: '#203864' }}>藥安全</Text>
                    < Text style={{ fontSize: 50, fontWeight: 'bold', textAlign: 'center',color: '#203864', marginBottom: 20 }}>Welcome!</Text>
                </View>
                
                <View
                    style={{
                        heigher: 38,
                        
                        borderRadius: 10,
                        width: 300,
                        flexDirection: 'row',
                        alignItems: 'center',
                        borderWidth: 2,
                        borderColor: "#AAA",
                        marginBottom: 20
                    }}>

                    <TextInput
                        placeholder="電子郵件"
                        style={{ fontSize: 34, fontWeight: 'bold', flex: 1, paddingVertical: 0, textAlign: 'center' }}
                        value={email}
                        onChangeText={ value=> setEmail( value)}
                        keyboardType="email-address" />
                </View>
                <View
                    style={{
                        heigher: 36,
                        borderRadius: 10,
                        width: 300,
                        flexDirection: 'row',
                        alignItems: 'center',
                        borderWidth: 2,
                        borderColor: "#AAA",
                        marginBottom: 20
                    }}>

                    <TextInput
                        placeholder="密碼"
                        secureTextEntry={true}
                        style={{ fontSize: 33, fontWeight: 'bold', flex: 1, paddingVertical: 0, textAlign: 'center' }}
                        value={password}
                        onChangeText={( value) => setPassword( value)} />
                </View>
                

                <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                    <TouchableOpacity
                        onPress={() => navigation.navigate("SignUp")}
                        style={{
                            heigher: 100,
                            borderRadius: 15,
                            width: 150,
                            backgroundColor: '#d9d9d9',
                            flexDirection: 'row',
                            alignItems: 'flex-start',
                            justifyContent: 'center',
                        }}>
                        <Text style={{ textAlign: 'center', fontWeight: '700', fontSize: 30, color: '#203864' }}>註冊</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                        onPress={handleSubmit}
                        style={{
                            heigher: 50,
                            backgroundColor: '#203864',
                            borderRadius: 15,
                            width: 150,

                            flexDirection: 'row',
                            alignItems: 'flex-start',
                            justifyContent: 'center',
                        }}>
                        <Text style={{ textAlign: 'center', fontWeight: '700', fontSize: 30, color: '#fff' }}>登入</Text>
                    </TouchableOpacity>

                </View>
                </KeyboardAwareScrollView>

            </View>    
  );
  }

const styles = StyleSheet.create({
    header : {
        flex: 1,
        backgroundColor :'#f5f7fc',
        alignItems:'center',
        justifyContent:'center',
     },
     imageStyle: {
        flex: 1,
        marginTop: 35,
        alignItems: 'center',
        width: 300,  // 這裡的尺寸可以根據你的需求來調整
        height: 300,
        resizeMode: 'contain',  // 這會讓圖片在組件中完整顯示
        marginVertical: 20,   // 上下間距，也可以根據你的需求來調整
        justifyContent: 'center', 
    },
        
});

