import { StyleSheet } from 'react-native';

export const HdScreenStyle = StyleSheet.create({
  container: {
    backgroundColor: '#E3E7ED',
    marginTop: 74,
    padding: 'auto',
    borderWidth: 10,
    borderColor: '#E3E7ED',
    borderRadius: 30,
    borderWidth: 10,
    
  },

  container2: {
    backgroundColor: '#E3E7ED',
    marginTop: '5%',
    padding: 'auto',
    borderWidth: 10,
    borderColor: '#E3E7ED',
    borderRadius: 30,
    borderWidth: 10,
  },

  title: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'left',
    marginLeft: '5%',
  }
});
