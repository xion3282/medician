import React, { useState } from 'react';
import { StyleSheet, View, Text, TextInput, TouchableOpacity, Button } from 'react-native';
import RadioForm, { RadioButton, RadioButtonInput, RadioButtonLabel } from 'react-native-simple-radio-button';
import { KeyboardAwareScrollView } from 'react-native-keyboard-aware-scroll-view';
import { useNavigation } from '@react-navigation/native';
import { auth } from '../../config.js';
import { createUserWithEmailAndPassword } from '@firebase/auth';
import { getFirestore, doc, setDoc, collection, addDoc } from '@firebase/firestore';

export default function SignupScreen() {
  const navigation = useNavigation();
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [value, setValue] = useState(0);

  const db = getFirestore();

  const items = [
    { label: "男性", value: 0 },
    { label: "女性", value: 1 },
    { label: "其他", value: 2 },
  ];

  const handleSubmit = async () => {
    if (email && password) {
      try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        // 存储用户数据到 Firestore
        const userDocRef = doc(db, "users", user.uid);
        
        await setDoc(userDocRef, {
          username: username,
          email: email,
          phoneNumber: phoneNumber,
          gender: items[value].label,  // 使用选择的性别
          // ... 其他你想要存储的数据
        });
      } catch (err) {
        console.log('got error:', err.message);
      }
    }
  };
  
  return (
    <KeyboardAwareScrollView style={{backgroundColor:'#f5f7fc'}}>
    <View style={styles.container}>

        <Text style={styles.title}>註冊</Text>

        <View style={[inputStyles.inputContainer, { marginBottom: 25 }]}>
          <Text style={inputStyles.inputTitle}>姓名</Text>
          <TextInput
            style={inputStyles.input}
            placeholder="請輸入姓名"
            value={username}
            onChangeText={(text) => setUsername(text)}
          />
        </View>

        <View style={inputStyles.inputContainer}>
          <Text style={inputStyles.inputTitle}>性別</Text>
          <RadioForm>
            {
              items.map((obj, index) => (
                <RadioButton style={{marginBottom: 10 ,marginTop: 8}} key={index}>
                  <RadioButtonInput
                    obj={obj}
                    index={index}
                    isSelected={index === value}
                    onPress={(value) => setValue(value)}
                    borderWidth={2.5}
                    buttonInnerColor='#203864'
                    buttonOuterColor={index === value ? '#203864' : '#000'}
                    buttonSize={20}
                    buttonWrapStyle={{ marginRight: 20}}
                  />

                  <RadioButtonLabel
                    obj={obj}
                    index={index}
                    labelStyle={{ 
                      color: index === value ? '#203864' : '#000',
                      fontSize: 19,
                      fontWeight: 'bold' 
                    }}
                  />
                </RadioButton>
              ))
            }
          </RadioForm>
        </View>
<View style={[inputStyles.inputContainer, { marginBottom: 25 }]}>
          <Text style={inputStyles.inputTitle}>密碼</Text>
          <TextInput
            style={inputStyles.input}
            placeholder="請輸入密碼"
            value={password}
            onChangeText={(  value) => setPassword(  value)}
            secureTextEntry={true}
          />
        </View>

        <View style={[inputStyles.inputContainer, { marginBottom: 25 }]}>
          <Text style={inputStyles.inputTitle}>電話</Text>
          <TextInput
            style={inputStyles.input}
            placeholder="請輸入電話"
            value={phoneNumber}
            onChangeText={(  value) => setPhoneNumber(  value)}
            keyboardType="phone-pad"
          />
        </View>

        <View style={[inputStyles.inputContainer, { marginBottom: 25 }]}>
          <Text style={inputStyles.inputTitle}>電子郵件</Text>
          <TextInput
            style={inputStyles.input}
            placeholder="請輸入電子郵件"
            value={email}
            onChangeText={( value) => setEmail(  value)}
            keyboardType="email-address"
          />
        </View>

        <TouchableOpacity style={buttonStyles.button} onPress ={handleSubmit} >
        <Text style={buttonStyles.buttonText}>註冊</Text>
        </TouchableOpacity>
         <TouchableOpacity style={buttonStyles.button1}  onPress={() => navigation.navigate("Login")} >
         <Text style={buttonStyles.ButtonText1}>返回</Text>
        </TouchableOpacity>
    </View>
  </KeyboardAwareScrollView>
);
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    // backgroundColor: '#EEEFF1',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 20,
    borderWidth: 30,
    borderColor: '#fff',
    borderRadius: 60,
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 'auto',
  },
  radioContainer: {
    marginTop: 20,
  },
  radioTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    marginBottom: 10,
  },
});

const buttonStyles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor:'#f5f7fc',
  },
  button1: {
    backgroundColor: '#d9d9d9',
    padding: 10,
    borderRadius: 10,
    width: '30%',
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  ButtonText1: {
    color: 'black',
    fontSize: 25,
    textAlign: 'center',
    marginBottom: 'auto',
  },
  ButtonText: {
    color: '#fff',
    fontSize: 25,
    textAlign: 'center',
    marginBottom: 'auto',
  },
  button: {
    backgroundColor: '#203864',
    padding: 10,
    borderRadius: 10,
    width: '30%',
    marginTop: 5,
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 25,
    textAlign: 'center',
  },
});

const inputStyles = StyleSheet.create({
  inputContainer: {
    width: '80%',
    flexDirection: 'column',
    alignItems: 'flex-start',
    marginBottom: 'auto',
  },
  inputTitle: {
    fontSize: 28,
    textAlign: 'left',
    marginBottom: 'auto',
    fontWeight: 'bold',
  },
  input: {
    width: '100%',
    height: 50,
    borderWidth: 1,
    borderColor: '#D9D9D9',
    borderRadius: 5,
    padding: 10,
    fontSize: 20,
    marginTop: 20,
    marginBottom: 'auto',
  },
});