import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, TouchableOpacity,ScrollView} from 'react-native';
import { auth, firestore } from '../../config';
import { doc, getDoc, collection, onSnapshot } from '@firebase/firestore';  // 注意這裡新增了 onSnapshot

export default function FamilyNicknameScreen({ navigation }) {
  const [familyMembers, setFamilyMembers] = useState([]);

  useEffect(() => {
    const user = auth.currentUser;
    if (!user) {
      console.error("用戶未登錄");
      return;
    }

    const userDocRef = doc(firestore, 'users', user.uid);

    // 用 onSnapshot 監聽資料庫變化
    const unsubscribe = onSnapshot(collection(userDocRef, 'memberdata'), (snapshot) => {
      const members = snapshot.docs.map(doc => ({
        familyMemberUid: doc.data().familyMemberUid,
        nickname: doc.data().nickname
      }));
      setFamilyMembers(members);
    });

    // 在 useEffect 的清理函數中取消監聽
    return () => unsubscribe();
  }, []);

  return (
    <ScrollView style={{backgroundColor: "#f5f7fc"}}>
    <View style={styles.container}>
      {familyMembers.map((member, index) => (
        <TouchableOpacity 
          key={index} 
          style={styles.nicknameButton} 
          onPress={() => {
            navigation.navigate('FnScreen', { familyMemberUid: member.familyMemberUid })
          }}
        >
          <Text style={styles.nicknameText}>{member.nickname}</Text>
        </TouchableOpacity>
      ))}
    </View></ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 16,
    backgroundColor: '#F5F7FC',
    alignItems: 'center',
    justifyContent: 'flex-start',  // 修改此行，將内容置於開始位置
  },
  nicknameText: {
    fontSize: 30,
    fontWeight: 'bold',
    color: 'black',
  },
  nicknameButton: {
    width: '85%',
    height: 130,
    backgroundColor: '#ccd9ff',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 50,   // 控制按鈕距離屏幕頂部的距離
    marginBottom: 30,
    borderRadius: 30,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 10,
    },
    shadowOpacity: 0.25,  // 添加這行以控制陰影的透明度
    shadowRadius: 10,     // 添加這行以控制陰影的模糊半徑
  },
});