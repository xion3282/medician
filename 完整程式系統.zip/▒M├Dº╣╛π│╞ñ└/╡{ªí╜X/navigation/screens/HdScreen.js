import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, Dimensions, FlatList, StyleSheet, ScrollView, Alert } from 'react-native';
import CalendarStrip from 'react-native-slideable-calendar-strip';
import { Ionicons } from '@expo/vector-icons';
import { auth, firestore } from '../../config';
import { onSnapshot, addDoc, collection, doc, deleteDoc, query, where } from '@firebase/firestore';

export default function HdScreen({ navigation }) {
    const [bmi, setBmi] = useState(null);
    const [data, setData] = useState([]);
    const [selectedDate, setSelectedDate] = useState(new Date());
    const user = auth.currentUser;
    if (!user) return;
    const uid = user.uid;
    const userDocRef = doc(firestore, 'users', uid);
    const whCollectionRef = collection(userDocRef, 'HeightWeight');
    const bsCollectionRef = collection(userDocRef, 'BloodSugar');
    const bpCollectionRef = collection(userDocRef, 'BloodPressure');

    const updateDataWithSnapshot = (snapshot, category) => {
        const newData = snapshot.docs.map(doc => ({
            id: doc.id,
            category: category,
            ...doc.data(),
        }));
        setData(prevData => {
            const filteredData = prevData.filter(item => item.category !== category);
            return [...filteredData, ...newData];
        });
    };

    useEffect(() => {
        const user = auth.currentUser;
        if (!user) return;
        const uid = user.uid;
        const userDocRef = doc(firestore, 'users', uid);
        const whCollectionRef = collection(userDocRef, 'HeightWeight');
        const bsCollectionRef = collection(userDocRef, 'BloodSugar');
        const bpCollectionRef = collection(userDocRef, 'BloodPressure');
        const formattedDate = formatDate(selectedDate);
        const whQuery = query(whCollectionRef, where('createdWH', '==', formattedDate));
        const bsQuery = query(bsCollectionRef, where('createdBS', '==', formattedDate));
        const bpQuery = query(bpCollectionRef, where('createdBP', '==', formattedDate));

        const unsubscribeWh = onSnapshot(whQuery, snapshot => {
            console.log("HeightWeight data: ", snapshot.docs);
            updateDataWithSnapshot(snapshot, 'HeightWeight');

            if (snapshot.docs.length) {
                const latestRecord = snapshot.docs[0].data();
                if (latestRecord.height && latestRecord.weight) {
                    const heightInMeters = parseFloat(latestRecord.height) / 100;
                    const weightInKg = parseFloat(latestRecord.weight);
                    const calculatedBmi = (weightInKg / (heightInMeters * heightInMeters)).toFixed(2);
                    setBmi(calculatedBmi);
                }
            }
        });
        const unsubscribeBs = onSnapshot(bsQuery,
            snapshot => {
                console.log("BloodSugar data: ", snapshot.docs);
                updateDataWithSnapshot(snapshot, 'BloodSugar');
            },
            error => {
                console.error("Error fetching BloodSugar data: ", error);
            }
        );
        const unsubscribeBp = onSnapshot(bpQuery,
            snapshot => {
                console.log("BloodPressure data: ", snapshot.docs);
                updateDataWithSnapshot(snapshot, 'BloodPressure');
            },
            error => {
                console.error("Error fetching BloodSugar data: ", error);
            }
        );
        return () => {
            unsubscribeWh();
            unsubscribeBs();
            unsubscribeBp();
        };
    }, [selectedDate]);

    const handleLongPress = (id, category) => {
        Alert.alert(
            '警告',
            '你確定要刪除這個數據嗎？',
            [
                {
                    text: "取消",
                    style: "cancel"
                },
                {
                    text: "確定",
                    onPress: () => deleteData(id, category)
                }
            ]
        );
    }
    const deleteData = (id, category) => {
        let ref;
        switch (category) {
            case 'HeightWeight':
                ref = whCollectionRef;
                break;
            case 'BloodPressure':
                ref = bpCollectionRef;
                break;
            case 'BloodSugar':
                ref = bsCollectionRef;
                break;
        }
        deleteDoc(doc(ref, id)).then(() => {
            console.log("刪除成功！");
            // 從本地state中移除該數據
            setData(prevData => prevData.filter(item => item.id !== id));
        }).catch((error) => {
            console.error("錯誤刪除數據: ", error);
        });
    };
    const formatDate = (date) => {
        const offset = date.getTimezoneOffset();
        const localDate = new Date(date.getTime() - (offset * 60 * 1000));
        return localDate.toISOString().split('T')[0];
    };
    const getCategoryTitle = (category) => {
        switch (category) {
            case 'HeightWeight':
                return '身高 體重';
            case 'BloodPressure':
                return '血壓';
            case 'BloodSugar':
                return '血糖';
            default:
                return category;
        }
    };

    return (
        <View style={{ flex: 1 }}>
            <CalendarStrip
                selectedDate={selectedDate}
                onPressDate={(date) => {
                    setSelectedDate(date);
                    const formattedDate = formatDate(date);
                    console.log("Formatted Date: ", formattedDate);
                }}
                onPressGoToday={(today) => {
                    setSelectedDate(today);
                }}
                markedDate={['2018-05-04', '2018-05-15', '2018-06-04', '2018-05-01']}
                weekStartsOn={1}
                dateNumberStyle={{ color: 'white' }}
            />
            <View style={{ flex: 1 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'flex-end', margin: 10 }}>
                    <TouchableOpacity onPress={() => navigation.navigate('新增身體資訊', { selectedDate: selectedDate })}>
                        <Ionicons name="add-circle-outline" size={40} color="#002080" />
                    </TouchableOpacity>
                </View>
                <FlatList
                    style={{ flex: 1, marginHorizontal: 10 }}
                    data={data}
                    numColumns={1}
                    renderItem={({ item }) => (
                        <TouchableOpacity
                            style={styles.container}
                            onPress={() => {
                                if (item.category === 'HeightWeight') {
                                    navigation.navigate('更新身高體重', { data: item, selectedDate: selectedDate });
                                }
                                 else if (item.category === 'BloodPressure') {
                                    navigation.navigate('更新血壓', { data: item, selectedDate: selectedDate });
                                } 
                                else if (item.category === 'BloodSugar') {
                                    navigation.navigate('更新血糖', { data: item, selectedDate: selectedDate });
                                }
                            }}
                            onLongPress={() => handleLongPress(item.id, item.category)}
                        >
                            <View style={styles.innerContainer}>
    <Text style={styles.itemHeading}>{getCategoryTitle(item.category)}</Text>

    {item.category === 'HeightWeight' && (
        <View>
            <Text style={styles.itemText}>
                身高 {item.height} {"\n"}體重 {item.weight}
            </Text>
            <Text style={styles.itemText}>
                BMI {(parseFloat(item.weight) / (parseFloat(item.height) / 100) ** 2).toFixed(1)}
            
            {/* BMI Category Messages */}
            {parseFloat(item.weight) / (parseFloat(item.height) / 100) ** 2 < 18.5 && (
                 <Text style={styles.warningText}>{"\n"}<Ionicons name="warning" size={20} color="#b30000" />過輕</Text>
            )}
            {parseFloat(item.weight) / (parseFloat(item.height) / 100) ** 2 >= 24 && parseFloat(item.weight) / (parseFloat(item.height) / 100) ** 2 < 27 && (
                 <Text style={styles.warningText}>{"\n"}<Ionicons name="warning" size={20} color="#b30000" />過重</Text>
            )}
            {parseFloat(item.weight) / (parseFloat(item.height) / 100) ** 2 >= 27 && parseFloat(item.weight) / (parseFloat(item.height) / 100) ** 2 < 30 && (
                <Text style={styles.warningText}>{"\n"}<Ionicons name="warning" size={20} color="#b30000" />輕度肥胖</Text>
            )}
            {parseFloat(item.weight) / (parseFloat(item.height) / 100) ** 2 >= 30 && parseFloat(item.weight) / (parseFloat(item.height) / 100) ** 2 < 35 && (
                <Text style={styles.warningText}>{"\n"}<Ionicons name="warning" size={20} color="#b30000" />中度肥胖</Text>
            )}
            {parseFloat(item.weight) / (parseFloat(item.height) / 100) ** 2 >= 35 && (
                 <Text style={styles.warningText}>{"\n"}<Ionicons name="warning" size={20} color="#b30000" />重度肥胖</Text>
            )}</Text>
        </View>
    )}

    {item.category === 'BloodSugar' && (
        <Text style={styles.itemText}>
            {item.mealTime} 血糖 {item.glucose}
            {item.mealTime == '飯前' && item.glucose > 100 ? (
                <Text style={styles.warningText}>{"\n"}<Ionicons name="warning" size={20} color="#b30000" />血糖數值異常</Text>
            ) : null}
            {item.mealTime == '飯後' && item.glucose > 140 ? (
                <Text style={styles.warningText}>{"\n"}<Ionicons name="warning" size={20} color="#b30000" />血糖數值異常</Text>
            ) : null}
        </Text>
    )}
                                {item.category === 'BloodSugar' && (
                                    <Text style={styles.itemText}>
                                        {item.mealTime} 血糖 {item.glucose}
                                        {item.mealTime == '飯前' && item.glucose > 100 ? (
                                            <Text style={styles.warningText}>{"\n"}<Ionicons name="warning" size={20} color="#b30000" />血糖數值異常</Text>
                                        ) : null}
                                        {item.mealTime == '飯後' && item.glucose > 140 ? (
                                            <Text style={styles.warningText}>{"\n"}<Ionicons name="warning" size={20} color="#b30000" />血糖數值異常</Text>
                                        ) : null}
                                    </Text>
                                )}
                                {item.category === 'BloodPressure' && (
                                    <Text style={styles.itemText}>
                                        收縮壓 {item.diastolicPressure} {"\n"}舒張壓 {item.systolicPressure}
                                        {item.diastolicPressure > 120 || item.systolicPressure > 80 ? (
                                            <Text style={styles.warningText}>{"\n"}<Ionicons name="warning" size={20} color="#b30000" />血壓數值異常</Text>
                                        ) : null}
                                    </Text>
                                )}
                            </View>
                        </TouchableOpacity>
                    )}
                    contentContainerStyle={{ paddingBottom: 20 }}
                />
            </View>
        </View>
    );
}

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#ccd9ff',
        padding: 30,
        borderRadius: 15,
        margin: 5,
        marginHorizontal: 10,
    },
    innerContainer: {
        alignContent: 'center',
        flexDirection: 'column',
    },
    itemHeading: {
        fontWeight: 'bold',
        color: '#002080',
        fontSize: 25,
        lineHeight: 45,
    },
    itemText: {
        fontWeight: '500',
        color: '#00134d',
        fontSize: 20,
        lineHeight: 35,
    },
    warningText: {
        fontSize: "20",
        color: '#b30000',
    }
});
