import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Dimensions, TextInput, StyleSheet } from 'react-native';
import PickerSelect from 'react-native-picker-select';
import { firebase } from '../../config';
import { useNavigation } from '@react-navigation/native';

const width = Dimensions.get('window').width;

const pickerSelectStyles = StyleSheet.create({
  inputIOS: {
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 18, // 調整左側內邊距
    borderWidth: 0,
    borderRadius: 10,
    color: 'black',
    paddingRight: 20,
    paddingLeft: 15, // Remove left padding for the placeholder
    marginRight: 5, // Move the select box to the left
    backgroundColor: '#203864',
    color: 'white',
    marginTop: 2,
  },
  inputAndroid: {
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 18, // 調整左側內邊距
    borderWidth: 0,
    borderRadius: 10,
    color: 'black',
    paddingRight: 20,
    paddingLeft: 15, // Remove left padding for the placeholder
    marginRight: 5, // Move the select box to the left
    backgroundColor: '#203864',
    color: 'white',
    marginTop: 2,
  },
});

const BsdelScreen = () => {
  const navigation = useNavigation()
  const todoRef = firebase.firestore().collection('Blood Sugar');
  const [glucose, setGlucose] = useState('');
  const [mealTime, setMealTime] = useState('飯前');

  const updatebs = () => {
    if (glucose > 0) {
      const timestamp = firebase.firestore.FieldValue.serverTimestamp();
      const data = {
        glucose: glucose,
        mealTime: mealTime,
        createdBP: timestamp,
      };
      todoRef
        .add(data)
        .then(() => {

          setGlucose('');
          setMealTime('飯前');

        })

        .catch((erro) => {

          alert(erro);

        })
    }
  };

  const handleDelete = () => {
    // 執行刪除操作的邏輯
    console.log('刪除');
    // 清空輸入框的數值
    setGlucose('');
    setSystolicPressure('');
  };

  return (
    <View style={{ flex: 1 }}>

      <View style={styles.inputContainer}>
        <Text style={styles.bloodPressureText}>血糖</Text>

        <View style={styles.inputRow}>
          <PickerSelect
            value={mealTime}
            onValueChange={(value) => setMealTime(value)}
            items={[
              { label: '飯前', value: '飯前' },
              { label: '飯後', value: '飯後' },
            ]}
            style={pickerSelectStyles}
            useNativeAndroidPickerStyle={false}
            placeholder=""
          />
          <TextInput
            placeholder="輸入血糖"
            value={glucose}
            onChangeText={(glucose) => setGlucose(glucose)}
            style={styles.input}
          />
          <Text style={styles.unitText}>mg/dl</Text>
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity onPress={updatebs} style={styles.addButton}>
            <Text style={styles.buttonText}>新增</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('健康日誌')} style={styles.cancelButton}>
            <Text style={styles.buttonText}>取消</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleDelete} style={styles.cancelButton}>
            <Text style={styles.buttonText}>刪除</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}

export default BsdelScreen;

const styles = StyleSheet.create({
  inputContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 10,
    borderWidth: 32,
    borderColor: '#535E6D',
  },
  bloodPressureText: {
    fontSize: 40,
    fontWeight: 'bold',
    marginBottom: 22,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  input: {
    flex: 1,
    height: 50,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 10, //框的圓弧度
    marginBottom: 15,
    paddingHorizontal: 50,
  },
  unitText: {
    fontSize: 22,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginTop: 20,
  },
  addButton: {
    backgroundColor: '#203864',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginRight: 10,
  },
  cancelButton: {
    backgroundColor: '#BFBFBF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginRight: 10,
  },
  deleteButton: {
    backgroundColor: '#BFBFBF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginRight: 10,
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 20,
  },
});
