import React, { useState, useEffect } from 'react';
import { View, Text, TextInput, TouchableOpacity, StyleSheet, Alert } from 'react-native';
import { firestore, auth } from '../../config';
import { doc, updateDoc } from '@firebase/firestore';

const formatDate = (date) => {
    const offset = date.getTimezoneOffset();
    const localDate = new Date(date.getTime() - (offset * 60 * 1000));
    return localDate.toISOString().split('T')[0];
};


export default function Bpupdata({ route, navigation }) {
    const { data, selectedDate } = route.params;
    const [diastolicPressure, setDiastolicPressure] = useState(data.diastolicPressure);
    const [systolicPressure, setSystolicPressure] = useState(data.systolicPressure);

    const handleUpdate = async () => {
        try {
            const user = auth.currentUser;
            if (!user) return;

            const uid = user.uid;
            const userDocRef = doc(firestore, 'users', uid);
            const bpDocRef = doc(userDocRef, 'BloodPressure', data.id);

            await updateDoc(bpDocRef, {
                diastolicPressure: diastolicPressure,
                systolicPressure: systolicPressure,
                createdBP: formatDate(selectedDate),
            });

            Alert.alert("更新成功");
            navigation.goBack(); // 返回到 HdScreen 畫面
        } catch (error) {
            console.error("更新錯誤: ", error);
            Alert.alert("更新錯誤", "請稍後再試");
        }
    };

    return (
        <View style={{ flex: 1 }}>
            <View style={styles.inputContainer}>
                <Text style={styles.bloodPressureText}>血壓</Text>
                <View style={styles.inputRow}>
                    <View style={styles.labelContainer}>
                        <Text style={styles.labelText}>收縮壓</Text>
                    </View>
                    <TextInput
                        value={diastolicPressure.toString()}
                        onChangeText={setDiastolicPressure}
                        style={styles.input}
                        keyboardType="numeric"
                        placeholder="輸入舒張壓"
                    />
                    <Text style={styles.unitText}>mmHg</Text>
                </View>
                <View style={styles.inputRow}>
                <View style={styles.labelContainer}>
                    <Text style={styles.labelText}>舒張壓</Text>
                </View>
                <TextInput
                    value={systolicPressure.toString()}
                    onChangeText={setSystolicPressure}
                    style={styles.input}
                    keyboardType="numeric"
                    placeholder="輸入收縮張"
                />
                <Text style={styles.unitText}>mmHg</Text>
            </View>
            <Text style={styles.reminderText}>(提醒:收縮壓為較大之數值，舒張壓為較小之數值)</Text>
            <View style={styles.buttonContainer}>
                <TouchableOpacity onPress={() => navigation.navigate('健康日誌')} style={styles.cancelButton}>
                    <Text style={styles.buttonText}>取消</Text>
                </TouchableOpacity>

                <TouchableOpacity onPress={handleUpdate} style={styles.addButton}>
                    <Text style={styles.buttonText}>更新</Text>
                </TouchableOpacity>
            </View>
        </View>
        </View >
    );
}

const styles = StyleSheet.create({
    inputContainer: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: 'white',
        padding: 10,
        borderWidth: 32,
        borderColor: '#535E6D', // 調整邊框顏色
    },
    bloodPressureText: {
        fontSize: 40,
        fontWeight: 'bold',
        marginBottom: 22,
    },
    inputRow: {
        flexDirection: 'row',
        alignItems: 'center',
        marginBottom: 10,
    },
    labelContainer: {
        backgroundColor: '#2F5597',
        paddingHorizontal: 10,
        paddingVertical: 10,
        borderRadius: 5,
        marginRight: 5,
    },
    labelText: {
        fontSize: 22,
        fontWeight: 'bold',
        color: 'white',
    },
    input: {
        height: 50,
        width: 165,
        borderColor: 'gray',
        borderWidth: 1,
        borderRadius: 10,
        marginBottom: 15,
        paddingHorizontal: 35,
        marginTop: 20,
        textAlign: 'center',
        fontSize: 25,
    },
    unitText: {
        fontSize: 22,
        fontWeight: 'bold',
        marginLeft: 5,
    },
    reminderText: {
        fontSize: 13,
        marginTop: 1,
    },
    buttonContainer: {
        flexDirection: 'row',
        justifyContent: 'flex-start',
        marginTop: 20,
    },
    addButton: {
        backgroundColor: '#203864',
        paddingHorizontal: 20,
        paddingVertical: 10,
        borderRadius: 5,
    },
    cancelButton: {
        backgroundColor: '#BFBFBF',
        paddingHorizontal: 20,
        paddingVertical: 10,
        borderRadius: 5,
        marginRight: 50,
        marginLeft: 10,
    },
    buttonText: {
        color: '#FFFFFF',
        fontWeight: 'bold',
        textAlign: 'center',
        fontSize: 20,
    },
});
