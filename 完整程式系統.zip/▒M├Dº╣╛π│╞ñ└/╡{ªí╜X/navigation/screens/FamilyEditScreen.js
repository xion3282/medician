import React, { useState } from 'react';
import { StyleSheet, Text, TextInput, Switch, View, TouchableOpacity, ScrollView } from 'react-native';
import { auth, firestore } from '../../config';
import { addDoc, collection, serverTimestamp, doc, getDoc, updateDoc } from '@firebase/firestore';

// 檢查授權碼是否有效的函數
const checkAuthorizationCode = async (authorizationCode) => {
  try {
    const userDocRef = doc(firestore, 'users', authorizationCode);
    const userDocSnapshot = await getDoc(userDocRef);

    if (userDocSnapshot.exists()) {
      // 授權碼即是有效的使用者ID
      return true;
    } else {
      // 授權碼不是有效的使用者ID
      return false;
    }
  } catch (error) {
    console.error('檢查授權碼時出錯：', error);
    return false;
  }
};

export default function FamilyEditScreen({ navigation }) {
  const [nickname, setNickname] = useState('');
  const [account, setAccount] = useState('');
  const [authorizationCode, setAuthorizationCode] = useState('');
  const [receiveNotification, setReceiveNotification] = useState(false);

  // fyAddon 函數
const fyAddon = async () => {
  try {
    const user = auth.currentUser;
    if (!user) {
      alert('用戶未登錄');
      return;
    }

    const uid = user.uid;
    if (!nickname || !account || !authorizationCode) {
      alert("請填寫所有字段");
      return;
    }

    // 檢查授權碼是否有效
    const isAuthorized = await checkAuthorizationCode(authorizationCode);

    if (!isAuthorized) {
      alert('無效的家屬授權碼');
      return;
    }

    const userDocRef = doc(firestore, 'users', uid);
    const memberDataCollectionRef = collection(userDocRef, 'memberdata');

    const timestamp = serverTimestamp();
    const data = {
      nickname,
      account,
      authorizationCode,
      receiveNotification,
      createdBP: timestamp,
      familyMemberUid: authorizationCode,  // 使用authorizationCode作為家屬UID
    };
    
    await addDoc(memberDataCollectionRef, data);

    // 更新當前用戶的文檔以保存家屬UID
    await updateDoc(userDocRef, { familyMemberUid: authorizationCode });

    // 导航到 SettingsScreen
    navigation.navigate('設定');

    setNickname('');
    setAccount('');
    setAuthorizationCode('');
    setReceiveNotification(false);

    alert('家屬資料已成功新增');
  } catch (error) {
    console.error('保存數據出錯：', error);
    alert('保存數據出錯');
  }
};

  return (
    <ScrollView style={{backgroundColor: "#f5f7fc"}}>
      <View style={styles.container}>
        <Text style={styles.title}>家屬設定</Text>
        <Text style={styles.label}>家屬暱稱</Text>
        <TextInput
          style={styles.input}
          value={nickname}
          onChangeText={setNickname}
          placeholder="輸入家屬暱稱"
        />
        <Text style={styles.label}>家屬帳號</Text>
        <TextInput
          style={styles.input}
          value={account}
          onChangeText={setAccount}
          placeholder="輸入家屬帳號"
        />
        <Text style={styles.label}>家屬授權碼</Text>
        <TextInput
          style={styles.input}
          value={authorizationCode}
          onChangeText={setAuthorizationCode}
          placeholder="輸入家屬授權碼"
        />
        <View style={styles.switchContainer}>
          <Switch value={receiveNotification} onValueChange={setReceiveNotification} />
          <Text style={styles.switchLabel}>是否接受家屬服藥通知</Text>
        </View>
        <View style={styles.buttonContainer}>
          <TouchableOpacity style={styles.cancelButton} onPress={() => navigation.navigate('Member')}>
            <Text style={styles.buttonText}>取消</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.saveButton} onPress={fyAddon}>
            <Text style={styles.buttonText}>儲存</Text>
          </TouchableOpacity>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 40, //版面寬度
    paddingVertical: 135, //版面長度
    padding: 10,
    borderWidth: 25,
    borderColor: '#535E6D',
    borderRadius: 40, //框的圓弧度
    backgroundColor: '#F5F7FC',
    paddingTop: 50 // 增加 paddingTop 屬性
  },   
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 15,
    textAlign: 'center', // 新增此行來將標題置中
  },
    label: {
      fontSize: 25, //框的字體大小
      fontWeight: 'bold',
      marginBottom: 15,
    },
    input: {
      height: 55, //框的高度
      borderColor: 'darkgray',
      borderWidth: 2, //框的粗度
      borderRadius: 10, //邊框的弧度
      marginBottom: 28, //框之間的間距
      paddingHorizontal: 10, //框裡字的位置
    },
      saveButton: {
        backgroundColor: '#203864',
        paddingHorizontal: 20,
        paddingVertical: 10,
        borderRadius: 5,
        marginLeft: 20,
        marginTop:10,  
      },
      cancelButton: {
        backgroundColor: '#BFBFBF',
        paddingHorizontal: 20,
        paddingVertical: 10,
        borderRadius: 5,
        marginRight: 30,
        marginTop:10,  
      },
      buttonText: {
        color: '#FFFFFF',
        fontWeight: 'bold',
        textAlign: 'center',
        fontSize: 20,
      },
      buttonContainer: {
        flexDirection: 'row', // 水平排列
        justifyContent: 'space-between', // 平均分配空间
        marginTop: 0, // 调整按钮之间的间距
      },
      switchContainer: {
        flexDirection: 'row', // 新增此行來將開關和標籤並排
        alignItems: 'center', // 使開關和標籤在垂直方向上對齊
        marginBottom: 15, // 如果需要，您可以添加一些底部邊距
      },
      switchLabel: {
        marginLeft: 10, // 也許您想要一些空間在開關和標籤之間
        fontSize: 17,
      },
  });
