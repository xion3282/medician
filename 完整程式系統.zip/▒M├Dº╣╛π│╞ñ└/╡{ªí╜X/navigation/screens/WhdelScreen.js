import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Dimensions, TextInput, StyleSheet } from 'react-native';
import { firebase } from '../../config';
import { useNavigation } from '@react-navigation/native';

const width = Dimensions.get('window').width;

const WhdelScreen = () => {
  const navigation = useNavigation()
  const todoRef = firebase.firestore().collection('Height & Weight');
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');

  const updatawh = () => {
    if (height && weight > 0) {
      const timestamp = firebase.firestore.FieldValue.serverTimestamp();
      const data = {
        height: height,
        weight: weight,
        createdWH: timestamp,
      };
      todoRef
        .add(data)
        .then(() => {

          setHeight('');
          setWeight('');

        })

        .catch((erro) => {

          alert(erro);

        })
    }
  };

  const handleDelete = () => {
    // 執行刪除操作的邏輯
    console.log('刪除');
    // 清空輸入框的數值
    setHeight('');
    setWeight('');
  };

  return (
    <View style={{ flex: 1 }}>

      <View style={styles.inputContainer}>
        <View style={styles.inputRow}>
          <Text style={styles.label}>身高</Text>
          <TextInput
            placeholder="輸入身高"
            value={height}
            onChangeText={setHeight}
            style={styles.input}
          />
        </View>

        <View style={styles.inputRow}>
          <Text style={styles.label}>體重</Text>
          <TextInput
            placeholder="輸入體重"
            value={weight}
            onChangeText={setWeight}
            style={styles.input}
          />
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity onPress={updatawh} style={styles.addButton}>
            <Text style={styles.buttonText}>更新</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={handleDelete} style={styles.deleteButton}>
            <Text style={styles.buttonText}>刪除</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={() => navigation.navigate('健康日誌')} style={styles.cancelButton}>
            <Text style={styles.buttonText}>取消</Text>
          </TouchableOpacity>
        </View>
      </View>

    </View>
  );
}

export default WhdelScreen;

const styles = StyleSheet.create({
  inputContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 10,
    borderWidth: 40,
    borderColor: '#535E6D', // 調整邊框顏色
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  label: {
    fontSize: 30,
    fontWeight: 'bold',
    marginRight: 15, // 調整文字與框框之間的距離
  },
  input: {
    height: 50,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 10,
    marginBottom: 25,
    paddingHorizontal: 50,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginTop: 20,
  },
  addButton: {
    backgroundColor: '#203864',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginRight: 20,
    marginLeft: 10,
  },
  deleteButton: {
    backgroundColor: '#BFBFBF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginRight: 20,
  },
  cancelButton: {
    backgroundColor: '#BFBFBF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginRight: 10,
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 20,
  },
});
