import React, { useState } from 'react';
import { View, Text, TouchableOpacity,  TextInput, StyleSheet } from 'react-native';
import { auth, firestore } from '../../config';
import { addDoc, collection, doc } from '@firebase/firestore';

const formatDate = (date) => {
  const offset = date.getTimezoneOffset();
  const localDate = new Date(date.getTime() - (offset * 60 * 1000));
  return localDate.toISOString().split('T')[0];
};

export default function WhScreen ({ navigation, route }) {
  const { selectedDate } = route.params;
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');

  const whauth = async () => {
    try {
      const user = auth.currentUser;
      if (!user) {
        alert('用戶未登錄');
        return;
      }      
      const uid = user.uid;
      const userDocRef = doc(firestore, 'users', uid);
      const whRef = collection(userDocRef, 'HeightWeight');
      const data = {
        height: height,
        weight: weight,
        createdWH: formatDate(selectedDate),
      };
      await addDoc(whRef, data);
      navigation.navigate('健康日誌');
      setHeight('');
      setWeight('');

    } catch (error) {
      console.error("保存數據出錯：", error);
      alert("保存數據出錯");
    }
  }

  return (
    <View style={{ flex: 1,backgroundColor: "#f5f7fc"
  }}>
      <View style={styles.inputContainer}>
        <View style={styles.inputRow}>
          <Text style={styles.label}>身高</Text>
          <TextInput
            placeholder="輸入身高"
            value={height}
            onChangeText={setHeight}
            style={styles.input}
            keyboardType='numeric'
            maxLength={6}
          />
        </View>

        <View style={styles.inputRow}>
          <Text style={styles.label}>體重</Text>
          <TextInput
            placeholder="輸入體重"
            value={weight}
            onChangeText={setWeight}
            style={styles.input}
            keyboardType='numeric'
            maxLength={6}
          />
        </View>

        <View style={styles.buttonContainer}>
          <TouchableOpacity onPress={() => navigation.navigate('健康日誌')} style={styles.cancelButton}>
            <Text style={styles.buttonText}>取消</Text>
          </TouchableOpacity>

          <TouchableOpacity onPress={whauth} style={styles.addButton}>
            <Text style={styles.buttonText}>新增</Text>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  inputContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 10,
    borderWidth: 40,
    borderColor: '#535E6D',
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
    justifyContent: 'center',
  },
  label: {
    fontSize: 30,
    fontWeight: 'bold',
    marginRight: 15, // 調整文字與框框之間的距離
  },
  input: {
    height: 50,
    width: 165,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 10,
    marginBottom: 25,
    paddingHorizontal: 50,
    textAlign: 'center',
    fontSize:15,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginTop: 20,
  },
  addButton: {
    backgroundColor: '#203864',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    
  },
  cancelButton: {
    backgroundColor: '#BFBFBF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginRight: 50,
    marginLeft: 10,
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 20,
  },
});
