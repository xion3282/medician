import React, { useState, useEffect } from 'react';
import { View, Text, TouchableOpacity, TextInput, StyleSheet, Alert,ScrollView} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { getAuth } from 'firebase/auth';
import { getFirestore, doc, getDoc, updateDoc } from 'firebase/firestore';
import RadioForm from 'react-native-simple-radio-button';

function EditDataMemberScreen() {
  const [username, setUsername] = useState('');
  const [gender, setGender] = useState(0);
  const [phoneNumber, setPhoneNumber] = useState('');
  const [email, setEmail] = useState('');
  const navigation = useNavigation();
  const [showSuccess, setShowSuccess] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      const auth = getAuth();
      const user = auth.currentUser;
      const db = getFirestore();
      if (user) {
        const userDocRef = doc(db, 'users', user.uid);
        const userDoc = await getDoc(userDocRef);
        if (userDoc.exists()) {
          const data = userDoc.data();
          setUsername(data.username || '');
          setGender(data.gender || 0);
          setPhoneNumber(data.phoneNumber || '');
          setEmail(data.email || '');
        }
      }
    };
    fetchData();
  }, []);

  const handleSave = async () => {
    try {
      const auth = getAuth();
      const user = auth.currentUser;
      const db = getFirestore();
      if (user) {
        const userDocRef = doc(db, 'users', user.uid);
        await updateDoc(userDocRef, {
          username, gender, phoneNumber, email,
        });
        setShowSuccess(true);
        setTimeout(() => navigation.navigate('DataMember'), 2000);
      }
    } catch (error) {
      console.error('Error updating document:', error);
      Alert.alert('更新錯誤', '請再試一次。');
    }
  };

  const genderOptions = [
    { label: '男性', value: 0 },
    { label: '女性', value: 1 },
  ];

  return (
    <ScrollView style={{backgroundColor: "#f5f7fc" }}>
    <View style={styles.container}>
      <Text style={styles.title}>會員資料</Text>
      <View style={styles.fieldContainer}>
        <Text style={styles.label}>姓名: </Text>
        <TextInput
          style={styles.input}
          placeholder="Username"
          value={username}
          onChangeText={setUsername}
        />
      </View>
      <View style={styles.fieldContainer}>
        <Text style={styles.label}>性別: </Text>
        <RadioForm
          style={styles.radioButton}
          radio_props={genderOptions}
          initial={gender}
          onPress={setGender}
          buttonSize={10}
          buttonOuterSize={20}
          labelStyle={styles.radioButtonLabel}
          buttonColor={'#000000'} // Black color buttons
          selectedButtonColor={'#000000'} // Black color selected button
        />
      </View>
      <View style={styles.fieldContainer}>
        <Text style={styles.label}>電話: </Text>
        <TextInput
          style={styles.input}
          placeholder="Phone Number"
          value={phoneNumber}
          onChangeText={setPhoneNumber}
          keyboardType="phone-pad"
        />
      </View>
      <View style={styles.fieldContainer}>
        <Text style={styles.label}>Email: </Text>
        <TextInput
          style={styles.input}
          placeholder="Email"
          value={email}
          onChangeText={setEmail}
          keyboardType="email-address"
        />
      </View>
      <View style={styles.buttonContainer}>  
        <TouchableOpacity onPress={() => navigation.navigate('DataMember')} style={styles.cancelButton}>
          <Text style={styles.buttonText}>取消</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={() => { handleSave(); navigation.navigate('DataMember'); }} style={styles.saveButton}>
          <Text style={styles.buttonText}>更新</Text>
        </TouchableOpacity>

      </View>
      {showSuccess && <Text style={styles.successMessage}>會員資料更新成功!</Text>}
    </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    paddingHorizontal: 40,
    paddingVertical: 135,
    padding: 10,
    borderWidth: 25,
    borderColor: '#535E6D',
    borderRadius: 40,
    backgroundColor: '#F5F7FC',
    paddingTop: 50
  },
  title: {
    fontSize: 35,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
  },
  fieldContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 35,
  },
  label: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  input: {
    flex: 1,
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    paddingLeft: 10,
  },
  radioButton: {
    flex: 1,
  },
  radioButtonLabel: {
    fontSize: 20,
    
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 0,
  },
  saveButton: {
    backgroundColor: '#203864',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginLeft: 20,
    marginTop: 10,  
  },
  cancelButton: {
    backgroundColor: '#BFBFBF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginRight: 30,
    marginTop: 10,  
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 20,
  },
  successMessage: {
    marginTop: 20,
    color: 'green',
    fontSize: 20,
    textAlign: 'center',
  },
});

export default EditDataMemberScreen;
