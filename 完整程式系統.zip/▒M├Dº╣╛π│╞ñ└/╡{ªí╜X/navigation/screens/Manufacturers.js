import React from 'react';
import { View, Text, TouchableOpacity, Image, StyleSheet, Dimensions, ScrollView } from 'react-native';

const windowWidth = Dimensions.get('window').width;

const Manufacturers = ({ navigation }) => {
  const renderTableCells = () => {
    const cells = [];
    const data = [
      { name: '申請廠商名稱', content: '克里薩斯生技股份有限公司' },
      { name: '申請商統一編號', content: '16100027' },
      { name: '製造商名稱', content: '十全實業股份有限公司' },
    ];

    for (let i = 0; i < 4; i++) {
      const cellData = data[i] || {};
      cells.push(
        <View key={i} style={styles.tableCell}>
          <Text style={styles.cellText}>
            {cellData.name}{'\n'}
            {cellData.content}
          </Text>
        </View>
      );
    }
    return cells;
  };

  return (
    <View style={{ flex: 1 }}>
      <View style={{ flex: 0.09, alignItems: 'center', justifyContent: 'center', backgroundColor: '#203864' }}>
        <View style={styles.buttonContainer}>
          <TouchableOpacity onPress={() => navigation.navigate('搜尋資料詳細資訊')}
            style={[styles.button]}>
            <Text style={styles.buttonText}>藥物</Text>
          </TouchableOpacity>
          <TouchableOpacity style={[styles.button]}>
            <Text style={styles.buttonText}>廠商</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={{ flex: 0.91 }}>
        <ScrollView>
          <View style={{ alignItems: 'center', justifyContent: 'center', backgroundColor: 'white', width: windowWidth }}>
            <View style={styles.tableRow}>
              {renderTableCells()}
            </View>
          </View>
        </ScrollView>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'space-around',
    width: '100%',
    flex: 1,
  },
  button: {
    backgroundColor: '#203864',
    padding: 10,
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  buttonText: {
    color: 'white',
    fontSize: 20,
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    width: '100%',
  },
  tableCell: {
    width: '100%',
    height: 70,
    borderWidth: 1,
    borderColor: '#ccc',
    alignItems: 'flex-start',
    justifyContent: 'center',
    paddingLeft: 10,
  },
  cellText: {
    fontSize: 16,
    textAlign: 'left',
  },
  cellImage: {
    width: 50,
    height: 50,
    resizeMode: 'contain',
  },
});

export default Manufacturers;


 

