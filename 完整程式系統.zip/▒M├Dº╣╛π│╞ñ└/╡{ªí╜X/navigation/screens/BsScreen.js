import React, { useState } from 'react';
import { View, Text, TouchableOpacity, Dimensions, TextInput, StyleSheet } from 'react-native';
import PickerSelect from 'react-native-picker-select';
import { auth, firestore } from '../../config';
import { addDoc, collection, doc } from '@firebase/firestore';

const formatDate = (date) => {
  const offset = date.getTimezoneOffset();
  const localDate = new Date(date.getTime() - (offset * 60 * 1000));
  return localDate.toISOString().split('T')[0];
};

const pickerSelectStyles = StyleSheet.create({
  inputIOS: {
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 18, // 調整左側內邊距
    borderWidth: 0,
    borderRadius: 10,
    color: 'black',
    paddingRight: 20,
    paddingLeft: 15, // Remove left padding for the placeholder
    marginRight: 5, // Move the select box to the left
    backgroundColor: '#203864',
    color: 'white',
    marginTop: 2,
  },
  inputAndroid: {
    fontSize: 16,
    paddingVertical: 12,
    paddingHorizontal: 18, // 調整左側內邊距
    borderWidth: 0,
    borderRadius: 10,
    color: 'black',
    paddingRight: 20,
    paddingLeft: 15, // Remove left padding for the placeholder
    marginRight: 5, // Move the select box to the left
    backgroundColor: '#203864',
    color: 'white',
    marginTop: 2,
  },
});

export default function BsScreen({ navigation, route }) {
  const { selectedDate } = route.params;
  const [glucose, setGlucose] = useState('');
  const [mealTime, setMealTime] = useState('飯前');

  const bsauth = async () => {
    try {
      const user = auth.currentUser;
      if (!user) {
        alert('用戶未登錄');
        return;
      }

      const uid = user.uid;
      const userDocRef = doc(firestore, 'users', uid);
      const bsRef = collection(userDocRef, 'BloodSugar');
      const data = {
        glucose: glucose,
        mealTime: mealTime,
        createdBS: formatDate(selectedDate),
      };

      await addDoc(bsRef, data);
      navigation.navigate('健康日誌');
      setGlucose('');
      setMealTime('');

    } catch (error) {
      console.error("保存數據出錯：", error);
      alert("保存數據出錯");
    }
  }

  return (
    <View style={{ flex: 1 }}>
      <View style={styles.inputContainer}>
        <Text style={styles.bloodSugarText}>血糖</Text>
        <View style={styles.inputRow}>
          <PickerSelect
            value={mealTime}
            onValueChange={(value) => setMealTime(value)}
            items={[
              { label: '飯前', value: '飯前' },
              { label: '飯後', value: '飯後' },
            ]}
            style={pickerSelectStyles}
            useNativeAndroidPickerStyle={false}
            placeholder="" // Remove the placeholder text
          />
          <TextInput
            placeholder="輸入血糖"
            value={glucose}
            onChangeText={(glucose) => setGlucose(glucose)}
            style={styles.input}
            keyboardType='numeric'
            maxLength={6}
          />
          <Text style={styles.unitText}>mg/dl</Text>
        </View>
        <View style={styles.buttonContainer}>
          <TouchableOpacity onPress={() => navigation.navigate('健康日誌')} style={styles.cancelButton}>
            <Text style={styles.buttonText}>取消</Text>
          </TouchableOpacity>
          <TouchableOpacity onPress={bsauth} style={styles.addButton}>
            <Text style={styles.buttonText}>新增</Text>
          </TouchableOpacity>

        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  inputContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'white',
    padding: 10,
    borderWidth: 32,
    borderColor: '#535E6D',
  },
  bloodSugarText: {
    fontSize: 40,
    fontWeight: 'bold',
    marginBottom: 22,
  },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 10,
  },
  input: {
    flex: 1,
    height: 50,
    borderColor: 'gray',
    width: 165,
    borderWidth: 1,
    borderRadius: 10,//框的圓弧度
    marginBottom: 15,
    paddingHorizontal: 50,
    textAlign: 'center',
    fontSize: 15,
  },
  unitText: {
    fontSize: 22,
    fontWeight: 'bold',
    marginLeft: 5,
  },
  buttonContainer: {
    flexDirection: 'row',
    justifyContent: 'flex-start',
    marginTop: 20,
  },
  addButton: {
    backgroundColor: '#203864',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
  },
  cancelButton: {
    backgroundColor: '#BFBFBF',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
    marginRight: 50,
    marginLeft: 10,
  },
  buttonText: {
    color: '#FFFFFF',
    fontWeight: 'bold',
    textAlign: 'center',
    fontSize: 20,
  },
});
