import React, { useState, useEffect } from 'react';
import { View, Text, ActivityIndicator, ScrollView,Linking,TouchableOpacity,Image,StyleSheet } from 'react-native';
import { createMaterialTopTabNavigator } from '@react-navigation/material-top-tabs';
import { ref, get, onValue, off } from 'firebase/database';
import { getStorage, ref as storageRef, getDownloadURL } from 'firebase/storage';
import { database } from '../../config'; // 请确保路径是正确的


const TopTab = createMaterialTopTabNavigator();

function DrugInfo({ itemDetails, imageUrl }) {
  return (
    <ScrollView style={{ padding: 10,backgroundColor: '#F5F7FC'}}>
         <View style={styles.container}>
            {imageUrl && (
                <Image 
                    source={{ uri: imageUrl }}
                    style={styles.image}
                    resizeMode="contain" 
                />
            )}
        </View>
    {itemDetails.中文品名_x !== 0 && <Text style={styles.textStyle}>中文品名: {itemDetails.中文品名_x}</Text>}
    {itemDetails.英文品名_x !== 0 && <Text style={styles.textStyle}>英文品名: {itemDetails.英文品名_x}</Text>}
    {itemDetails.形狀 !== 0 && <Text style={styles.textStyle}>形狀: {itemDetails.形狀}</Text>}
    {itemDetails.劑型 !== 0 && <Text style={styles.textStyle}>劑型: {itemDetails.劑型}</Text>}
    {itemDetails.適應症 !== 0 && <Text style={styles.textStyle}>適應症: {itemDetails.適應症}</Text>}
    {itemDetails.用法用量 !== 0 && <Text style={styles.textStyle}>用法用量: {itemDetails.用法用量}</Text>}
    {itemDetails.包裝 !== 0 && <Text style={styles.textStyle}>包裝: {itemDetails.包裝}</Text>}
    {itemDetails.包裝與國際條碼 !== 0 && <Text style={styles.textStyle}>包裝與國際條碼: {itemDetails.包裝與國際條碼}</Text>}
    {itemDetails.藥品類別 !== 0 && <Text style={styles.textStyle}>藥品類別: {itemDetails.藥品類別}</Text>}
    {itemDetails.特殊劑型 !== 0 && <Text style={styles.textStyle}>特殊劑型: {itemDetails.特殊劑型}</Text>}
    {itemDetails.管制藥品分類級別 !== 0 && <Text style={styles.textStyle}>管制藥品分類級別: {itemDetails.管制藥品分類級別}</Text>}
    {itemDetails.許可證字號 !== 0 && <Text style={styles.textStyle}>許可證字號: {itemDetails.許可證字號}</Text>}
    {itemDetails.許可證種類 !== 0 && <Text style={styles.textStyle}>許可證種類: {itemDetails.許可證種類}</Text>}
    {itemDetails.註銷日期 !== 0 && <Text style={styles.textStyle}>註銷日期: {itemDetails.註銷日期}</Text>}
    {itemDetails.註銷狀態 !== 0 && <Text style={styles.textStyle}>註銷狀態: {itemDetails.註銷狀態}</Text>}
    {itemDetails.註銷理由 !== 0 && <Text style={styles.textStyle}>註銷理由: {itemDetails.註銷理由}</Text>}
    {itemDetails.仿單圖檔連結 !== 0 && (
    <View style={{ flexDirection: 'row' }}>
        <Text style={styles.textStyle}>仿單圖檔連結: </Text>
        <TouchableOpacity onPress={() => Linking.openURL(itemDetails.仿單圖檔連結)}>
            <Text style={{ color: 'blue',marginBottom: 10,fontSize:18,}}>[PDF連結]</Text>
        </TouchableOpacity>
    </View>
)}

{itemDetails.外盒圖檔連結 !== 0 && (
    <View style={{ flexDirection: 'row' }}>
        <Text style={styles.textStyle}>外盒圖檔連結: </Text>
        <TouchableOpacity onPress={() => Linking.openURL(itemDetails.外盒圖檔連結)}>
            <Text style={{ color: 'blue',marginBottom: 10,fontSize:18}}>[PDF連結]</Text>
        </TouchableOpacity>
    </View>
)}

{itemDetails.外觀圖檔連結 !== 0 && (
    <View style={{ flexDirection: 'row' }}>
        <Text style={styles.textStyle}>外觀圖檔連結: </Text>
        <TouchableOpacity onPress={() => Linking.openURL(itemDetails.外觀圖檔連結)}>
            <Text style={{ color: 'blue',marginBottom: 10,fontSize:18,}}>[PDF連結]</Text>
        </TouchableOpacity>
    </View>
)}

  </ScrollView>
  );
}

function IngredientInfo({ itemDetails }) {
  return (
    <ScrollView style={{ padding: 10,backgroundColor: '#F5F7FC'}}>
    {itemDetails.主成分略述 !== 0 && <Text style={styles.textStyle}>主成分略述:{itemDetails.主成分略述}</Text>}
    </ScrollView>
  );
}

function ManufacturerInfo({ itemDetails }) {
  return (
    <ScrollView style={{ padding: 10,backgroundColor: '#F5F7FC'}}>
     {itemDetails.申請商名稱 !== 0 && <Text style={styles.textStyle}>申請商名稱: {itemDetails.申請商名稱}</Text>}
     {itemDetails.申請商地址 !== 0 && <Text style={styles.textStyle}>申請商地址: {itemDetails.申請商地址}</Text>}
     {itemDetails.申請商統一編號 !== 0 && <Text style={styles.textStyle}>申請商統一編號: {itemDetails.申請商統一編號}</Text>}
    {itemDetails.製造商名稱 !== 0 && <Text style={styles.textStyle}>製造商名稱: {itemDetails.製造商名稱}</Text>}
     {itemDetails.製造廠公司地址 !== 0 && <Text style={styles.textStyle}>製造廠公司地址: {itemDetails.製造廠公司地址}</Text>}
     {itemDetails.製造廠國別 !== 0 && <Text style={styles.textStyle}>製造廠國別: {itemDetails.製造廠國別}</Text>}
      {itemDetails.製造廠廠址 !== 0 && <Text style={styles.textStyle}>製造廠廠址: {itemDetails.製造廠廠址}</Text>}
       {itemDetails.異動日期 !== 0 && <Text style={styles.textStyle}>異動日期: {itemDetails.異動日期}</Text>}
      {itemDetails.發證日期 !== 0 && <Text style={styles.textStyle}>發證日期: {itemDetails.發證日期}</Text>}
       {itemDetails.製程 !== 0 && <Text style={styles.textStyle}>製程: {itemDetails.製程}</Text>}
    </ScrollView>
  );
}

export default function DmScreen({ route }) {
    const { itemId } = route.params;
    const [itemDetails, setItemDetails] = useState(null);
    const [loading, setLoading] = useState(true);
    const [imageUrl, setImageUrl] = useState(null);

    useEffect(() => {
        const fetchData = async () => {
            const dbRef = ref(database, "med/" + itemId); // 使用 Realtime Database 的 ref
            onValue(dbRef, async (snapshot) => {
                const data = snapshot.val();
                if (data) {
                    setItemDetails(data);
                    const imageRefUrl = data.imageUrl;
    
                    if (imageRefUrl) {
                        const storage = getStorage();
                        const imageRef = storageRef(storage, imageRefUrl); // 使用 Storage 的 ref
                        try {
                            const url = await getDownloadURL(imageRef);
                            setImageUrl(url);
                        } catch (error) {
                            console.error("Error fetching image:", error);
                        }
                    }
                    setLoading(false);
                } else {
                    console.error("No data found for the given itemId.");
                }
            });
        };
    
        fetchData();
    
        // Cleanup listener on component unmount
        return () => {
            const dbRef = ref(database, "med/" + itemId);
            off(dbRef);
        };
    }, [itemId]);
    
      return (
        <View style={{ flex: 1 }}>
          {itemDetails ? (
            <TopTab.Navigator
                tabBarOptions={{
                    activeTintColor: 'white',
                    inactiveTintColor: 'white',
                    style: { backgroundColor:'#203864' }, //backgroundColor: '#F5F7FC'
                    labelStyle: { fontWeight: 'bold' },
                    indicatorStyle: { backgroundColor: 'white' },
                }}
            >
              <TopTab.Screen 
                name="藥品" 
                children={() => <DrugInfo itemDetails={itemDetails} imageUrl={imageUrl} />}
              />
              <TopTab.Screen name="成分" children={() => <IngredientInfo itemDetails={itemDetails} />} />
              <TopTab.Screen name="廠商" children={() => <ManufacturerInfo itemDetails={itemDetails} />} />
            </TopTab.Navigator>
          ) : (
            <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
              <Text>No details found for the selected item.</Text>
            </View>
          )}
        </View>
      );
    }
    const styles = StyleSheet.create({
      container: {
          flex: 1,  // Take up the entire screen height
          justifyContent: 'center',
          alignItems: 'center',
          marginBottom: 20,
          backgroundColor: '#F5F7FC',
      },
      image: {
        width: 400,  
        height: 400,
        backgroundColor: '#F5F7FC',
      },
      textStyle: {
        marginBottom: 10,
        fontSize:20,  // Adjust this value as per your requirement
    },
  });
 
  
  
  
  
  