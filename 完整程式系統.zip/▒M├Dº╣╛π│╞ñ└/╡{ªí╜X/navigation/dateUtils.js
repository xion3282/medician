export function extendDateBy30Days(timestamp) {
    const originalDate = new Date(timestamp);
    originalDate.setDate(originalDate.getDate() + 30);
    return originalDate.getTime();
  }
  